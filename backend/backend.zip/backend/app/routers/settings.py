import logging
from typing import Optional, Dict
from pydantic import BaseModel

from fastapi import APIRouter, Depends, status, Header

from app.database import get_db
from app.core.dependencies import CurrentUser
from app.core.security import verify_password, hash_password, encrypt_value, decrypt_value
from app.models.user import User
from app.models.tool import Tool
from app.schemas.agent import SUPPORTED_PROVIDERS, normalize_provider
from app.core.exceptions import NotFoundException

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

logger = logging.getLogger("ocin")

router = APIRouter()


# Provider name mapping: normalized (lowercase) -> display (capitalized)
# Frontend expects: OpenAI, Anthropic, Google, Mistral, OpenRouter, Grok, Qwen, DeepSeek, Ollama
PROVIDER_NAME_MAP = {
    "openai": "OpenAI",
    "anthropic": "Anthropic",
    "google": "Google",
    "ollama": "Ollama",
    "openrouter": "OpenRouter",
    "mistral": "Mistral",
    "xai": "Grok",  # xai is displayed as Grok in the frontend
    "qwen": "Qwen",
    "deepseek": "DeepSeek",
    "zai": "ZAI",
}


class ApiKeysOut(BaseModel):
    """Masked API keys by provider (lowercase for internal compatibility)."""
    OpenAI: Optional[str] = None
    Anthropic: Optional[str] = None
    Google: Optional[str] = None
    Ollama: Optional[str] = None
    OpenRouter: Optional[str] = None
    Mistral: Optional[str] = None
    Grok: Optional[str] = None
    Qwen: Optional[str] = None
    DeepSeek: Optional[str] = None
    ZAI: Optional[str] = None


class ApiKeyUpdate(BaseModel):
    provider: str
    api_key: str


class PlanUpdate(BaseModel):
    plan: str  # free | pro | business


class SuccessResponse(BaseModel):
    success: bool


def mask_api_key(key: str) -> str:
    """Mask API key for display."""
    if not key or len(key) < 8:
        return "••••"
    return f"{key[:4]}...••••"


async def get_or_create_provider_tool(
    db: AsyncSession,
    user_id: str,
    provider: str,
) -> Optional[Tool]:
    """Get or create a tool for storing provider API key."""
    result = await db.execute(
        select(Tool).where(
            Tool.user_id == user_id,
            Tool.source == "api_key",
            Tool.source_key == provider,
        )
    )
    tool = result.scalar_one_or_none()
    return tool


@router.get("/api-keys")
async def get_api_keys(
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_db),
):
    """Get masked API keys for the current user.

    Returns provider names capitalized to match frontend expectations:
    OpenAI, Anthropic, Google, Ollama, OpenRouter, Mistral, Grok, Qwen, DeepSeek, ZAI
    """
    user_id = str(current_user.id)
    masked_keys: Dict[str, Optional[str]] = {display: None for display in PROVIDER_NAME_MAP.values()}

    # Get all tools that store API keys
    result = await db.execute(
        select(Tool).where(
            Tool.user_id == user_id,
            Tool.source == "api_key",
            Tool.is_active == True,
        )
    )
    tools = result.scalars().all()

    for tool in tools:
        tool_normalized = normalize_provider(tool.source_key)
        if tool_normalized in PROVIDER_NAME_MAP and tool.config:
            try:
                # Try to decrypt the API key from config
                encrypted_key = tool.config.get("api_key")
                if encrypted_key:
                    key = decrypt_value(encrypted_key)
                    masked_value = mask_api_key(key)
                    display_name = PROVIDER_NAME_MAP[tool_normalized]
                    masked_keys[display_name] = masked_value
            except Exception:
                pass

    return masked_keys


@router.put("/api-keys")
async def update_api_key(
    key_data: ApiKeyUpdate,
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_db),
):
    """Store or update an API key for a provider."""
    user_id = str(current_user.id)
    provider = key_data.provider

    # Case-insensitive provider validation
    provider_normalized = normalize_provider(provider)
    if not any(normalize_provider(p) == provider_normalized for p in SUPPORTED_PROVIDERS):
        from fastapi import HTTPException
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": f"Invalid provider: {provider}", "code": "INVALID_PROVIDER"}
        )

    # Encrypt the API key
    encrypted_key = encrypt_value(key_data.api_key)

    # Get or create the tool (use normalized provider name for storage)
    tool = await get_or_create_provider_tool(db, user_id, provider_normalized)

    if tool:
        # Update existing tool - preserve existing config fields
        existing_config = dict(tool.config) if tool.config else {}
        existing_config["api_key"] = encrypted_key
        existing_config["api_token"] = encrypted_key  # store under both keys for compatibility
        tool.config = existing_config
        tool.is_active = True
    else:
        # Create new tool (store provider as lowercase)
        tool = Tool(
            user_id=user_id,
            name=f"{provider} API Key",
            source="api_key",
            source_key=provider_normalized,
            config={"api_key": encrypted_key},
            is_active=True,
        )
        db.add(tool)

    await db.commit()

    logger.info({"event": "update_api_key", "user_id": user_id, "provider": provider})
    return {"success": True}


@router.put("/plan")
async def update_user_plan(
    plan_data: PlanUpdate,
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_db),
):
    """Update the user's plan."""
    if plan_data.plan not in ["free", "pro", "business"]:
        from fastapi import HTTPException
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": "Invalid plan. Must be free, pro, or business", "code": "INVALID_PLAN"}
        )

    current_user.plan = plan_data.plan
    await db.commit()

    logger.info({"event": "update_plan", "user_id": str(current_user.id), "plan": plan_data.plan})
    return {"success": True}


@router.get("/api-keys-internal")
async def get_api_keys_internal(
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_db),
    x_self_call: Optional[str] = Header(None),
):
    """
    Get unmasked API keys for self-call tools (intent resolution).

    This endpoint is only meant to be called by agents via self-call.
    It returns unmasked keys for Anthropic and OpenAI, which are
    used for the cheap LLM call in resolve_integration.
    """
    # Verify this is a self-call request (from our own agent system)
    # In production, this could be validated with a shared secret or HMAC
    # For now, we allow any authenticated user to access their own keys
    # since the agent runs with the user's JWT token
    user_id = str(current_user.id)

    api_keys = []

    # Get all tools that store API keys
    result = await db.execute(
        select(Tool).where(
            Tool.user_id == user_id,
            Tool.source == "api_key",
            Tool.is_active == True,
        )
    )
    tools = result.scalars().all()

    for tool in tools:
        provider = tool.source_key
        if provider in ["anthropic", "openai"]:
            try:
                encrypted_key = tool.config.get("api_key")
                if encrypted_key:
                    decrypted_key = decrypt_value(encrypted_key)
                    api_keys.append({
                        "provider": provider,
                        "api_key": decrypted_key,
                    })
            except Exception as e:
                logger.warning({
                    "event": "decrypt_api_key_failed",
                    "user_id": user_id,
                    "provider": provider,
                    "error": str(e),
                })

    return {"api_keys": api_keys}


@router.delete("/api-keys/{provider}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_api_key(
    provider: str,
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_db),
):
    """Delete/disconnect an API key for a specific provider."""
    user_id = str(current_user.id)

    # Validate and normalize provider name
    provider_normalized = normalize_provider(provider)
    if not any(normalize_provider(p) == provider_normalized for p in SUPPORTED_PROVIDERS):
        from fastapi import HTTPException
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": f"Invalid provider: {provider}", "code": "INVALID_PROVIDER"}
        )

    # Find the tool storing this provider's API key
    result = await db.execute(
        select(Tool).where(
            Tool.user_id == user_id,
            Tool.source == "api_key",
            Tool.source_key == provider_normalized,
        )
    )
    tool = result.scalar_one_or_none()

    if not tool:
        raise NotFoundException(f"No API key found for provider '{provider}'")

    # Delete the tool
    await db.delete(tool)
    await db.commit()

    logger.info({"event": "delete_api_key", "user_id": user_id, "provider": provider})


@router.delete("/account", status_code=status.HTTP_204_NO_CONTENT)
async def delete_user_account(
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_db),
):
    """Delete the user and all their data (cascade)."""
    user_id = str(current_user.id)

    # Cascade delete will handle agents, tools, schedules, runs, etc.
    await db.delete(current_user)
    await db.commit()

    logger.info({"event": "delete_account", "user_id": user_id})
