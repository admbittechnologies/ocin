import logging
import asyncio
from typing import Optional
from pydantic import BaseModel, Field
import json

from fastapi import APIRouter, Depends, status, Request, Query, BackgroundTasks, HTTPException
from fastapi.responses import StreamingResponse
from slowapi import Limiter
from slowapi.util import get_remote_address
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from redis.asyncio import Redis

from app.database import get_db
from app.core.dependencies import CurrentUser
from app.core.security import decode_token, decrypt_value
from app.services.run_service import create_run
from app.services.agent_runner import run_agent
from app.config import settings
from app.core.exceptions import NotFoundException
from app.services.agent_service import get_agent
from app.schemas.agent import normalize_provider
from app.models.tool import Tool
from app.schemas.thread import ThreadOut, ThreadListItem, ThreadListResponse
from app.schemas.message import MessageOut, MessageListResponse
from app.services.thread_service import (
    create_thread,
    get_user_threads,
    get_thread,
    delete_thread,
    get_thread_messages,
)
from app.models.message import Message

logger = logging.getLogger("ocin")
limiter = Limiter(key_func=get_remote_address)

router = APIRouter()


async def get_redis() -> Redis:
    """Get Redis client."""
    return Redis.from_url(settings.REDIS_URL, decode_responses=False)


async def get_api_keys_for_provider(
    db: AsyncSession,
    user_id: str,
    provider_normalized: str,
) -> dict[str, str]:
    """
    Retrieve API keys for a given provider from tools table.

    API keys are stored in tools table with source='api_key' and
    provider name as source_key (lowercase).
    """
    result = await db.execute(
        select(Tool).where(
            Tool.user_id == user_id,
            Tool.source == "api_key",
            Tool.source_key == provider_normalized,
            Tool.is_active == True,
        )
    )
    tools = result.scalars().all()

    api_keys = {}
    for tool in tools:
        try:
            encrypted_key = tool.config.get("api_key")
            if encrypted_key:
                decrypted_key = decrypt_value(encrypted_key)
                api_keys[provider_normalized] = decrypted_key
        except Exception as e:
            logger.warning({
                "event": "get_api_keys_for_provider",
                "user_id": user_id,
                "provider": provider_normalized,
                "error": str(e),
            })

    return api_keys


class ChatSendRequest(BaseModel):
    """Request schema for sending a chat message."""
    agent_id: str
    message: str = Field(..., min_length=1, max_length=10000)
    thread_id: Optional[str] = None


class ChatSendResponse(BaseModel):
    """Response schema for chat send."""
    message_id: str
    thread_id: Optional[str] = None
    type: Optional[str] = None
    message: Optional[str] = None


@router.post("/send", response_model=ChatSendResponse)
@limiter.limit("30/minute")
async def send_chat_message(
    request: Request,
    data: ChatSendRequest,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db),
):
    """
    Send a chat message to an agent.

    If thread_id is provided, continues conversation in that thread.
    If no thread_id, creates a new thread and returns thread_id.

    Supports commands:
    - /clear — Clear conversation history and start fresh
    - /help — Show available commands
    """
    from app.services.run_service import RunCreate as RunCreateModel

    # Extract user from Authorization header
    auth_header = request.headers.get("authorization")
    if auth_header and auth_header.startswith("Bearer "):
        token = auth_header[7:]
        payload = decode_token(token)
        if payload and "sub" in payload:
            user_id = payload.get("sub")
        else:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail={"error": "Invalid authentication credentials", "code": "UNAUTHORIZED"}
            )
    else:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"error": "Missing authentication", "code": "UNAUTHORIZED"}
        )

    # Handle /help command
    if data.message.strip().lower() == "/help":
        help_text = """Available commands:
/clear — Clear conversation history and start fresh
/help  — Show this help message

Tips:
• I remember our conversation context automatically
• I can create Google Sheets, send Slack messages, manage HubSpot
• Ask me to remember things and I will store them in memory
• You can switch agents by typing @ followed by agent name"""
        return ChatSendResponse(
            message_id="help",
            type="help",
            message=help_text,
        )

    # Handle /clear command
    if data.message.strip().lower() == "/clear":
        # If thread_id is provided, delete all messages in that thread
        if data.thread_id:
            # Verify thread belongs to user
            thread = await get_thread(db, data.thread_id, user_id)
            if not thread:
                raise NotFoundException("Thread not found")

            # Delete all messages in this thread
            await db.execute(
                delete(Message).where(Message.thread_id == data.thread_id)
            )
            await db.commit()
            logger.info({
                "event": "thread_cleared",
                "thread_id": data.thread_id,
                "user_id": user_id,
            })

            # Publish cleared message to Redis so open SSE connections get it
            redis = await get_redis()
            await redis.publish(
                f"ocin:thread:{data.thread_id}:system",
                json.dumps({
                    "type": "cleared",
                    "message": "🧹 Conversation cleared. Starting fresh!",
                })
            )
            await redis.close()
        else:
            # No thread to clear
            return ChatSendResponse(
                message_id="cleared",
                type="cleared",
                message="No active conversation to clear.",
            )

        return ChatSendResponse(
            message_id="cleared",
            type="cleared",
            message="🧹 Conversation cleared. Starting fresh!",
        )

    # Verify agent belongs to user
    agent = await get_agent(db, data.agent_id, user_id)
    if not agent:
        raise NotFoundException("Agent not found")

    # Get or create thread
    thread_id = data.thread_id
    if thread_id:
        # Verify thread belongs to user
        thread = await get_thread(db, thread_id, user_id)
        if not thread:
            raise NotFoundException("Thread not found")
    else:
        # Create new thread with title from message (truncated to 50 chars)
        title = data.message[:50] + "..." if len(data.message) > 50 else data.message
        thread = await create_thread(db, user_id, data.agent_id, title=title)
        thread_id = str(thread.id)

    # Get API keys for agent's provider
    provider_normalized = normalize_provider(agent.model_provider)
    model_api_keys = await get_api_keys_for_provider(db, user_id, provider_normalized)

    # Create run record
    run = await create_run(
        db,
        RunCreateModel(
            user_id=user_id,
            agent_id=data.agent_id,
            input=data.message,
        ),
    )

    # Launch agent run in background
    redis = await get_redis()
    background_tasks.add_task(
        run_agent,
        run_id=str(run.id),
        agent_id=data.agent_id,
        user_id=user_id,
        input_text=data.message,
        db=db,
        redis=redis,
        model_api_keys=model_api_keys,
        thread_id=thread_id,
        jwt_token=token,
        api_base="http://api:8000",
    )

    logger.info({
        "event": "chat_send",
        "run_id": str(run.id),
        "thread_id": thread_id,
        "agent_id": data.agent_id,
        "user_id": user_id,
    })
    return ChatSendResponse(message_id=str(run.id), thread_id=thread_id)

async def chat_event_generator(run_id: str, token: str):
    """Generate SSE events for chat stream.

    Uses Redis list (RPUSH + LRANGE) instead of pub/sub to avoid race conditions.
    Late SSE subscribers can read from offset 0 and never miss anything.
    """
    redis = None
    stream_key = f"ocin:run:{run_id}:stream"
    cache_key = f"ocin:run:{run_id}:output"

    logger.info({"event": "stream_endpoint_called", "run_id": run_id})

    try:
        redis = Redis.from_url(settings.REDIS_URL, decode_responses=True)

        # Fast path: if run is already fully complete, replay from cache
        cached = await redis.get(cache_key)
        if cached:
            data = json.loads(cached)
            output = data.get("output", "")
            yield f"event: connected\ndata: {json.dumps({'type': 'connected'})}\n\n"
            yield f"event: token\ndata: {json.dumps({'type': 'token', 'token': output})}\n\n"
            yield f"event: done\ndata: {json.dumps({'type': 'done', 'run_id': run_id, 'status': 'success'})}\n\n"
            return

        yield f"event: connected\ndata: {json.dumps({'type': 'connected'})}\n\n"

        cursor = 0
        idle_loops = 0
        MAX_IDLE_LOOPS = 300  # ~5 min hard timeout

        while True:
            # Drain anything currently buffered in the list
            batch = await redis.lrange(stream_key, cursor, cursor + 99)
            if batch:
                cursor += len(batch)
                idle_loops = 0
                for raw in batch:
                    try:
                        msg_data = json.loads(raw)
                    except (json.JSONDecodeError, TypeError):
                        continue
                    if not isinstance(msg_data, dict):
                        continue
                    msg_type = msg_data.get("type", "token")
                    # Handle error messages specially — yield as error event and close stream
                    if msg_type == "error":
                        yield f"event: error\ndata: {json.dumps(msg_data)}\n\n"
                        return
                    yield f"event: {msg_type}\ndata: {json.dumps(msg_data)}\n\n"
                    if msg_type in ("done",):
                        return
                continue

            # List is empty — check if run finished while we were sleeping.
            # The publisher may have RPUSHed the full output, written to cache,
            # and deleted the list all within one of our polling intervals.
            cached = await redis.get(cache_key)
            if cached:
                data = json.loads(cached)
                output = data.get("output", "")
                yield f"event: token\ndata: {json.dumps({'type': 'token', 'token': output})}\n\n"
                yield f"event: done\ndata: {json.dumps({'type': 'done', 'run_id': run_id, 'status': 'success'})}\n\n"
                return

            # Nothing buffered and run not yet complete — sleep + heartbeat
            await asyncio.sleep(1)
            idle_loops += 1
            yield ": keepalive\n\n"
            if idle_loops >= MAX_IDLE_LOOPS:
                yield f"event: error\ndata: {json.dumps({'type': 'error', 'error': 'stream timeout'})}\n\n"
                return
    finally:
        if redis:
            await redis.close()


@router.get("/stream")
async def stream_chat(
    message_id: str = Query(...),
    token: str = Query(...),
):
    """Stream chat output via SSE."""
    # Verify token
    payload = decode_token(token)
    if payload is None or "sub" not in payload:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"error": "Invalid authentication credentials", "code": "UNAUTHORIZED"}
        )

    user_id = payload.get("sub")

    return StreamingResponse(
        chat_event_generator(message_id, token),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        }
    )


# Thread management endpoints

@router.get("/threads", response_model=ThreadListResponse)
async def list_threads(
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_db),
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
    agent_id: Optional[str] = None,
):
    """List all chat threads for current user."""
    threads, total = await get_user_threads(db, str(current_user.id), agent_id, skip, limit)

    thread_items = []
    for thread in threads:
        thread_items.append(ThreadListItem(
            id=str(thread.id),
            agent_id=str(thread.agent_id),
            title=thread.title,
            created_at=thread.created_at,
            last_message_at=thread.last_message_at,
            message_count=getattr(thread, "message_count", 0),
            last_message_preview=getattr(thread, "last_message_preview", None),
        ))

    return ThreadListResponse(threads=thread_items, total=total)


@router.get("/threads/{thread_id}", response_model=ThreadOut)
async def get_single_thread(
    thread_id: str,
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_db),
):
    """Get a single thread by ID."""
    thread = await get_thread(db, thread_id, str(current_user.id))
    if not thread:
        raise NotFoundException("Thread not found")

    return ThreadOut(
        id=str(thread.id),
        user_id=str(thread.user_id),
        agent_id=str(thread.agent_id),
        title=thread.title,
        created_at=thread.created_at,
        last_message_at=thread.last_message_at,
    )


@router.get("/threads/{thread_id}/messages", response_model=MessageListResponse)
async def list_thread_messages(
    thread_id: str,
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_db),
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=500),
):
    """Get all messages for a thread."""
    messages = await get_thread_messages(db, thread_id, str(current_user.id), limit=limit + skip)

    # Apply pagination
    paginated_messages = messages[skip:skip + limit]

    message_responses = [
        MessageOut(
            id=str(msg.id),
            thread_id=str(msg.thread_id),
            role=msg.role,
            content=msg.content,
            created_at=msg.created_at,
        )
        for msg in paginated_messages
    ]

    return MessageListResponse(messages=message_responses, total=len(messages))


@router.delete("/threads/{thread_id}")
async def delete_thread_endpoint(
    thread_id: str,
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_db),
):
    """Delete a thread and all its messages."""
    success = await delete_thread(db, thread_id, str(current_user.id))
    if not success:
        raise NotFoundException("Thread not found")

    return {"success": True}
