import logging
from typing import Optional

from fastapi import APIRouter, Depends, status, HTTPException
from fastapi.responses import JSONResponse

from sqlalchemy.ext.asyncio import AsyncSession
from fastapi import Query

from app.core.dependencies import CurrentUser, get_db
from app.core.exceptions import (
    NotFoundException,
    ApprovalRequestedException,
)
from app.schemas.approval import (
    ApprovalOut,
    ApprovalListResponse,
    ApprovalCreate,
    ApprovalResolve,
)
from app.services.approval_service import (
    create_approval,
    list_approvals,
    get_approval,
    resolve_approval,
    get_pending_approvals_count,
)
from app.services.run_service import create_run, update_run

logger = logging.getLogger("ocin")
router = APIRouter()


@router.get("", response_model=ApprovalListResponse)
@router.get("", response_model=ApprovalListResponse)
async def list_approvals_endpoint(
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_db),
    status_filter: str = Query("pending", alias="status"),
    limit: int = 50,
    offset: int = 0,
):
    """List approvals for current user, newest first."""
    try:
        approvals = await list_approvals(
            db=db,
            user_id=str(current_user.id),
            status=status_filter,
            limit=limit,
            skip=offset,
        )

        approval_list = [
            ApprovalOut(
                id=str(approval.id),
                user_id=str(approval.user_id),
                agent_id=str(approval.agent_id) if approval.agent_id else None,
                agent_name=approval.agent.name if approval.agent else None,
                run_id=str(approval.run_id) if approval.run_id else None,
                schedule_id=str(approval.schedule_id) if approval.schedule_id else None,
                kind=approval.kind,
                title=approval.title,
                description=approval.description,
                payload=approval.payload,
                status=approval.status,
                resolution_note=approval.resolution_note,
                expires_at=approval.expires_at,
                created_at=approval.created_at,
            )
            for approval in approvals
        ]

        return ApprovalListResponse(approvals=approval_list)

    except Exception as e:
        logger.error({"event": "list_approvals_error", "error": str(e)})
        raise HTTPException(
            status_code=500,
            detail={"error": str(e), "code": "INTERNAL_ERROR"},
        )


@router.get("/pending/count")
async def pending_approvals_count_endpoint(
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_db),
):
    """Return count of pending approvals for current user."""
    from app.services.approval_service import count_pending
    count = await count_pending(db, str(current_user.id))
    return {"count": count}


@router.get("/{approval_id}", response_model=ApprovalOut)
async def get_approval_endpoint(
    current_user: CurrentUser,
    approval_id: str,
):
    """
    Get full details of a specific approval.

    Path params:
        approval_id: UUID of approval to fetch

    Raises:
        NotFoundException if approval not found or doesn't belong to user
    """
    try:
        approval = await get_approval(
            db=current_user.db,
            approval_id=approval_id,
            user_id=str(current_user.id),
        )

        if not approval:
            raise NotFoundException(f"Approval {approval_id} not found")

        return ApprovalOut(
            id=str(approval.id),
            user_id=str(approval.user_id),
            agent_id=str(approval.agent_id) if approval.agent_id else None,
            agent_name=approval.agent.name if approval.agent else None,
            run_id=str(approval.run_id) if approval.run_id else None,
            schedule_id=str(approval.schedule_id) if approval.schedule_id else None,
            kind=approval.kind,
            title=approval.title,
            description=approval.description,
            payload=approval.payload,
            status=approval.status,
            resolution_note=approval.resolution_note,
            expires_at=approval.expires_at,
            created_at=approval.created_at,
        )

    except Exception as e:
        logger.error({"event": "get_approval_error", "approval_id": approval_id, "error": str(e)})
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"error": str(e), "code": "INTERNAL_ERROR"},
        )


@router.post("/{approval_id}/approve", status_code=status.HTTP_200_OK)
async def approve_approval(
    current_user: CurrentUser,
    approval_id: str,
    body: ApprovalResolve,
):
    """
    Approve an approval request.

    Path params:
        approval_id: UUID of approval to approve

    Request body:
        note: Optional note from user

    Action:
        - Mark approval as approved
        - Set resolved_at timestamp
        - Trigger continuation of paused run

    The original run that requested approval will get a new child run
    created on approval with approved payload.
    """
    try:
        approval = await resolve_approval(
            db=current_user.db,
            approval_id=approval_id,
            user_id=str(current_user.id),
            approved=True,
            note=body.note,
        )

        # Trigger continuation of paused run by creating a child run
        if approval.run_id:
            # Get the original run to extract details for continuation
            from app.models.run import Run
            from sqlalchemy import select
            result = await current_user.db.execute(
                select(Run).where(Run.id == approval.run_id)
            )
            original_run = result.scalar_one_or_none()

            if original_run:
                # Create child run with approved payload
                # The child run continues from where the parent paused
                continuation_input = f"Continuing from approved approval: {approval.title}"

                child_run = await create_run(
                    db=current_user.db,
                    run_data={
                        "user_id": str(original_run.user_id),
                        "agent_id": str(original_run.agent_id),
                        "schedule_id": str(original_run.schedule_id) if original_run.schedule_id else None,
                        "input": continuation_input,
                        "status": "pending",
                        "parent_run_id": str(original_run.id),  # Link to parent run
                    }
                )

                logger.info({
                    "event": "approval_continuation_created",
                    "approval_id": approval_id,
                    "parent_run_id": str(original_run.id),
                    "child_run_id": str(child_run.id),
                })

                # The original run status remains "awaiting_approval" to show it's paused
                # The child run will execute with the approved context
            else:
                logger.info({
                    "event": "approval_approved_no_continuation",
                    "approval_id": approval_id,
                    "reason": "No associated run_id",
                })

        return {"success": True}

    except Exception as e:
        logger.error({"event": "approve_approval_error", "approval_id": approval_id, "error": str(e)})
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"error": str(e), "code": "INTERNAL_ERROR"},
        )


@router.post("/{approval_id}/reject", status_code=status.HTTP_200_OK)
async def reject_approval(
    current_user: CurrentUser,
    approval_id: str,
    body: ApprovalResolve,
):
    """
    Reject an approval request.

    Path params:
        approval_id: UUID of approval to reject

    Request body:
        note: Optional note from user

    Action:
        - Mark approval as rejected
        - Set resolved_at timestamp
        - The paused run gets status="failed" with error="User rejected approval"

    The original run is NOT continued - no child run is created.
    """
    try:
        approval = await resolve_approval(
            db=current_user.db,
            approval_id=approval_id,
            user_id=str(current_user.id),
            approved=False,
            note=body.note,
        )

        # Mark the original run as failed with user rejection reason
        if approval.run_id:
            from app.services.run_service import update_run
            await update_run(
                db=current_user.db,
                run_id=str(approval.run_id),
                status="failed",
                error=f"User rejected approval: {body.note if body.note else 'No reason provided'}",
            )

        logger.info({
            "event": "approval_rejected",
            "approval_id": approval_id,
            "user_id": str(current_user.id),
        })

        return {"success": True}

    except Exception as e:
        logger.error({"event": "reject_approval_error", "approval_id": approval_id, "error": str(e)})
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"error": str(e), "code": "INTERNAL_ERROR"},
        )
