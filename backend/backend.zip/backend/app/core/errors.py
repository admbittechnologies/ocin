# app/core/errors.py
"""Translate raw LLM provider errors into friendly user-facing messages."""

def friendly_llm_error(raw_error: str) -> dict:
    """
    Given a raw error string from an LLM provider, return a dict with:
      - category: short machine-readable code (e.g. 'billing', 'rate_limit', 'auth', 'model_not_found', 'unknown')
      - message: human-readable message safe to show to user
      - raw: original raw error (for debugging / logs)
    """
    lower = (raw_error or "").lower()

    # Billing / credit issues
    if "credit balance" in lower or "insufficient" in lower or "quota" in lower or "billing" in lower:
        return {
            "category": "billing",
            "message": "The AI provider rejected this request because your account has no credits. Please top up your API credits and try again.",
            "raw": raw_error,
        }

    # Rate limits
    if "rate limit" in lower or "too many requests" in lower or "429" in lower:
        return {
            "category": "rate_limit",
            "message": "The AI provider is rate-limiting requests. Please wait a moment and try again.",
            "raw": raw_error,
        }

    # Auth / invalid API key
    if "authentication" in lower or "invalid api key" in lower or "unauthorized" in lower or "401" in lower:
        return {
            "category": "auth",
            "message": "The AI provider rejected your API key. Please check your API key configuration in Settings.",
            "raw": raw_error,
        }

    # Model not found / invalid
    if "model" in lower and ("not found" in lower or "does not exist" in lower or "invalid" in lower):
        return {
            "category": "model_not_found",
            "message": "The AI model configured for this agent is not available. Please edit the agent and select a different model.",
            "raw": raw_error,
        }

    # Context length
    if "context" in lower and ("length" in lower or "too long" in lower or "exceeds" in lower):
        return {
            "category": "context_length",
            "message": "The conversation is too long for this model. Start a new thread or clear history.",
            "raw": raw_error,
        }

    # Fallback
    return {
        "category": "unknown",
        "message": f"The agent couldn't complete this request. Error: {raw_error[:300]}",
        "raw": raw_error,
    }
