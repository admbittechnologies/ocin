import logging
from datetime import datetime
from typing import Any, Optional
from zoneinfo import ZoneInfo
import uuid

import httpx
from pydantic import BaseModel, Field

logger = logging.getLogger("ocin")


class HttpResult(BaseModel):
    """Result from http_fetch tool."""
    status_code: int
    body: str
    headers: dict[str, str] = Field(default_factory=dict)

    def to_dict(self) -> dict:
        return self.model_dump()


class DateTimeResult(BaseModel):
    """Result from get_datetime tool."""
    date: str
    time: str
    day_of_week: str
    unix_timestamp: int
    timezone: str

    def to_dict(self) -> dict:
        return self.model_dump()


async def http_fetch(
    url: str,
    method: str = "GET",
    body: Optional[str] = None,
    headers: Optional[dict[str, str]] = None,
    timeout: float = 15.0,
) -> HttpResult:
    """
    Make an HTTP request to a URL.

    Args:
        url: The URL to fetch
        method: HTTP method (GET, POST, etc.)
        body: Request body (for POST, PUT, etc.)
        headers: Request headers
        timeout: Request timeout in seconds

    Returns:
        HttpResult with status code, body (truncated to 10k chars), and headers
    """
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.request(
                method=method.upper(),
                url=url,
                content=body,
                headers=headers,
            )

            # Truncate body to 10k characters
            body_text = response.text
            if len(body_text) > 10000:
                body_text = body_text[:10000] + "... [truncated]"

            return HttpResult(
                status_code=response.status_code,
                body=body_text,
                headers=dict(response.headers),
            )
    except Exception as e:
        logger.error({"event": "http_fetch", "url": url, "error": str(e)})
        raise ValueError(f"HTTP request failed: {str(e)}")


def get_datetime(timezone: str = "UTC") -> DateTimeResult:
    """
    Get the current date and time.

    Args:
        timezone: IANA timezone identifier (e.g., "America/New_York", "UTC")

    Returns:
        DateTimeResult with date, time, day of week, unix timestamp, and timezone
    """
    try:
        tz = ZoneInfo(timezone)
        now = datetime.now(tz)

        return DateTimeResult(
            date=now.strftime("%Y-%m-%d"),
            time=now.strftime("%H:%M:%S"),
            day_of_week=now.strftime("%A"),
            unix_timestamp=int(now.timestamp()),
            timezone=timezone,
        )
    except Exception as e:
        logger.error({"event": "get_datetime", "timezone": timezone, "error": str(e)})
        # Fallback to UTC
        return get_datetime("UTC")


async def request_approval(
    kind: str,
    title: str,
    description: str,
    payload: dict = None,
) -> dict:
    """
    Request user approval for an agent action.

    When called by an agent, this tool pauses execution and requests
    user confirmation before proceeding. Used for:
    - Sending emails
    - Posting to social media
    - Creating resources that cost money
    - Any action the user wants to review before execution

    Args:
        kind: Type of approval (send_email, post_social, execute_action)
        title: Short user-facing summary
        description: Longer explanation
        payload: Full payload the agent wants to execute

    Returns:
        Dict with approval details that signals the agent runner to pause

    Behavior:
        1. Returns a special response that the agent runner detects
        2. The agent runner will catch this and pause execution
        3. User can then approve/reject via the approvals API
        4. If approved, a new child run continues execution
    """
    # Import here to avoid circular dependency
    from app.core.exceptions import ApprovalRequestedException

    # Return a special response that signals the agent runner to pause
    # The agent runner will detect this and create an approval record
    approval_id = str(uuid.uuid4())

    logger.info({
        "event": "approval_request_created",
        "approval_id": approval_id,
        "kind": kind,
        "title": title,
        "description": description,
    })

    # Return response that triggers pause in agent_runner
    # The agent_runner will create the actual Approval record
    return {
        "_approval_request": {
            "approval_id": approval_id,
            "kind": kind,
            "title": title,
            "description": description,
            "payload": payload,
        }
    }