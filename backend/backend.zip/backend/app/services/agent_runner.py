import logging
import time
import os
import re
import functools
from datetime import datetime
from typing import Any
import json

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from redis.asyncio import Redis
from pydantic_ai import Agent as PydanticAgent
from pydantic import BaseModel as PydanticBaseModel
from pydantic_ai.models.gemini import GeminiModel
from pydantic_ai.messages import ModelRequest, ModelResponse, UserPromptPart, TextPart

from app.models.run import Run
from app.models.agent import Agent as AgentModel
from app.models.tool import Tool
from app.services.tool_loader import build_tools_for_agent
from app.services.run_service import update_run, create_run
from app.services.thread_service import save_messages, get_thread_messages_for_context
from app.services.memory_extraction import extract_and_save_memory, format_memory_context
from app.services.approval_service import create_approval
from app.core.exceptions import ToolUnavailableException
from app.config import settings
from app.integrations.self_tools import set_self_call_context, clear_self_call_context, get_self_tools

logger = logging.getLogger("ocin")
BaseModel = PydanticBaseModel


def estimate_tokens(messages: list) -> int:
    """Rough token estimate: ~4 chars per token."""
    total_chars = sum(len(str(m)) for m in messages)
    return total_chars // 4


def convert_to_pydantic_messages(raw_messages: list) -> list[ModelRequest | ModelResponse]:
    """Convert plain dict messages to PydanticAI ModelMessage objects.

    PydanticAI's message_history parameter expects a sequence of ModelRequest
    and ModelResponse objects, not plain dicts. This function handles the conversion.

    Args:
        raw_messages: List of dicts with 'role' and 'content' keys

    Returns:
        List of ModelRequest (for user messages) or ModelResponse (for assistant messages)
    """
    result = []
    for msg in raw_messages:
        # Handle both dict and object types
        if isinstance(msg, dict):
            role = msg.get("role")
            content = msg.get("content")
        else:
            role = getattr(msg, "role", None)
            content = getattr(msg, "content", None)

        if not content or not isinstance(content, str):
            continue

        if role == "user":
            result.append(ModelRequest(parts=[UserPromptPart(content=content)]))
        elif role == "assistant":
            result.append(ModelResponse(parts=[TextPart(content=content)]))

    return result


def extract_tool_results(all_messages: list) -> str:
    """
    Extract tool call results from PydanticAI message history.
    Returns a compact summary to append to the assistant message
    so future context includes what tools actually returned.
    """
    tool_summaries = []
    try:
        for msg in all_messages:
            parts = getattr(msg, 'parts', [])
            for part in parts:
                part_type = type(part).__name__
                # ToolReturnPart contains what the tool returned
                if 'ToolReturn' in part_type or 'tool_return' in part_type.lower():
                    content = getattr(part, 'content', '')
                    tool_name = getattr(part, 'tool_name', '')
                    if content and len(str(content)) < 300:
                        tool_summaries.append(f"[{tool_name}: {content}]")
    except Exception as e:
        logger.debug({"event": "extract_tool_results_failed", "error": str(e)})
    return ' '.join(tool_summaries)


def wrap_tool_with_progress(tool_fn, redis_client, stream_key):
    """Wrap a tool function to emit progress updates via Redis."""
    @functools.wraps(tool_fn)
    async def wrapped(*args, **kwargs):
        tool_name = getattr(tool_fn, "__name__", str(tool_fn))

        # Progress messages for different tools
        progress_messages = {
            "google_sheet_create_spreadsheet": "📊 Creating Google Sheet...",
            "google_sheet_append_rows": "✍️ Adding rows to spreadsheet...",
            "google_sheet_get_values": "📖 Reading spreadsheet data...",
            "google_sheet_update_values": "✏️ Updating spreadsheet...",
            "google_sheet_get_spreadsheet": "🔍 Fetching spreadsheet info...",
            "slack_send_message": "💬 Sending Slack message...",
            "slack_list_channels": "📋 Fetching Slack channels...",
            "hubspot_create_contact": "👤 Creating HubSpot contact...",
            "hubspot_create_company": "🏢 Creating HubSpot company...",
            "hubspot_search_contacts": "🔍 Searching HubSpot contacts...",
            "hubspot_create_deal": "💼 Creating HubSpot deal...",
            "gmail_send_email": "📧 Sending email...",
            "gmail_list_emails": "📬 Fetching emails...",
        }
        start_msg = progress_messages.get(tool_name, f"⚙️ Running {tool_name}...")

        # Emit "working on it" message
        await redis_client.publish(stream_key, json.dumps({
            "type": "progress",
            "message": start_msg,
        }))

        # Execute the actual tool
        result = await tool_fn(*args, **kwargs)

        # Emit completion message with result preview
        completion_msg = None
        if isinstance(result, str):
            if "docs.google.com/spreadsheets" in result:
                # Extract URL from result
                urls = re.findall(r'https://docs\.google\.com/spreadsheets/d/[^\s"]+', result)
                if urls:
                    completion_msg = f"✅ Spreadsheet ready: {urls[0]}"
            elif "Updated" in result or "Appended" in result:
                completion_msg = f"✅ {result}"
            elif "Sent" in result or "sent" in result:
                completion_msg = f"✅ {result}"
            elif "Created" in result or "created" in result:
                completion_msg = f"✅ {result}"
            elif "Found" in result or "fetched" in result.lower():
                completion_msg = f"✅ {result}"

        if completion_msg:
            await redis_client.publish(stream_key, json.dumps({
                "type": "progress",
                "message": completion_msg,
            }))

        return result

    return wrapped


# Global prefix for all agents' system prompts
GLOBAL_PREFIX = """You are a proactive AI assistant. Follow these rules strictly:

1. ALWAYS use your tools immediately when asked — never ask for confirmation
   unless a critical piece of information is genuinely missing
2. NEVER ask what the user wants — they already told you, just do it
3. When a tool call fails, try a different approach before giving up
4. Remember everything in this conversation — do not ask for information
   already provided earlier in the chat
5. When using Maton tools, just call them directly with reasonable parameters
6. Confirm what you did after completing an action, briefly and clearly
   Respond in the SAME LANGUAGE as the user's input whenever possible.
7. Each request is independent — always execute fresh and report actual results
8. After EVERY tool action that creates or retrieves a resource, your response
   MUST include the complete details on a new line:
   - Spreadsheets: full URL and spreadsheet ID
   - Contacts/companies: record ID and name
   - Any resource: its ID and direct access link
   Format: "✅ Done. Access it here: [URL]" (or equivalent emoji/phrase in user's language)
   Never omit the URL or ID — users need them to access what you created.
9. After creating any resource via tools, immediately call set_memory to save
   key details so you can reference them later:
   - Spreadsheet: set_memory(key="{title}_url", value="{spreadsheetUrl}")
                 set_memory(key="{title}_id", value="{spreadsheetId}")
   - Contact: set_memory(key="contact_{email}", value="{contactId}")
   - Any resource: set_memory(key="{descriptive_name}", value="{id_or_url}")
"""

# Result type for agent runs (PydanticAI expects a typed result)
class AgentResult(BaseModel):
    """Typed result for agent execution."""
    output: str
    tool_calls: list[dict] = []


async def run_agent(
    run_id: str,
    agent_id: str,
    user_id: str,
    input_text: str,
    db: AsyncSession,
    redis: Redis,
    model_api_keys: dict[str, str] | None = None,
    thread_id: str | None = None,
    jwt_token: str | None = None,
    api_base: str = "http://localhost:8000",
    parent_run_id: str | None = None,
) -> str | None:
    """
    Execute an agent run and stream output to Redis.

    Args:
        run_id: The run ID
        agent_id: The agent ID
        user_id: The user ID
        input_text: The user input to process
        db: Database session
        redis: Redis client for streaming
        model_api_keys: Optional dict of model-specific API keys
        thread_id: Optional thread ID for chat history and message saving
        jwt_token: Optional JWT token for self-call tools
        api_base: Base URL for self-call API requests

    Returns:
        The output text if successful, None otherwise
    """
    start_time = time.time()
    stream_key = f"ocin:run:{run_id}:stream"
    tools_data = {"clients": []}  # Initialize before try block for finally block access
    output_text = None

    # Set self-call context if JWT token is provided
    if jwt_token:
        set_self_call_context(jwt_token, user_id, api_base)
        logger.debug({"event": "set_self_call_context", "user_id": user_id})

    async def stream_progress(message: str):
        """Stream a progress update to the user in real time."""
        await redis.rpush(stream_key, json.dumps({
            "type": "progress",
            "message": message,
        }))
        await redis.expire(stream_key, 600)

    async def stream_token(token: str):
        """Stream a single token to Redis."""
        await redis.rpush(stream_key, json.dumps({"type": "token", "token": token}))
        await redis.expire(stream_key, 600)

    async def stream_message(message: dict):
        """Stream a JSON message to Redis."""
        await redis.rpush(stream_key, json.dumps(message))
        await redis.expire(stream_key, 600)

    saved_env_vars = {}  # Track which env vars we modified
    try:
        # Load agent from DB
        result = await db.execute(
            select(AgentModel).where(AgentModel.id == agent_id, AgentModel.user_id == user_id)
        )
        agent = result.scalar_one_or_none()

        if not agent:
            raise ValueError(f"Agent {agent_id} not found")

        # Mark run as running and set started_at
        await update_run(
            db,
            run_id,
            status="running",
            started_at=datetime.utcnow(),
        )

        # Fetch user's API keys from database for this agent's provider
        provider_normalized = agent.model_provider.lower()
        result_keys = await db.execute(
            select(Tool).where(
                Tool.user_id == user_id,
                Tool.source == "api_key",
                Tool.source_key == provider_normalized,
                Tool.is_active == True,
            )
        )
        api_keys_from_db = {tool.source_key: tool.config.get("api_key") for tool in result_keys.scalars().all()}

        # Build tool list
        logger.info({"event": "run_agent", "run_id": run_id, "agent_id": agent_id, "status": "building_tools"})
        tools_data = await build_tools_for_agent(agent, db)
        tools = list(tools_data["tools"])  # Regular function tools
        mcp_servers = list(tools_data.get("mcp_servers", []))  # MCP server instances

        # Wrap Maton tools with progress streaming
        wrapped_tools = []
        for tool in tools:
            tool_name = getattr(tool, "__name__", "")
            if tool_name.startswith("google_sheet_") or \
               tool_name.startswith("slack_") or \
               tool_name.startswith("hubspot_") or \
               tool_name.startswith("gmail_"):
                wrapped_tools.append(wrap_tool_with_progress(tool, redis, stream_key))
            else:
                wrapped_tools.append(tool)
        tools = wrapped_tools

        # Add self-call tools if JWT token is provided
        if jwt_token:
            self_tools = get_self_tools()
            tools.extend(self_tools)
            logger.info({"event": "self_tools_added", "count": len(self_tools)})

        # Load message history if thread_id is provided
        message_history = []
        if thread_id:
            raw_history = await get_thread_messages_for_context(
                db, thread_id, user_id, limit=20
            )

            # Separate conversational messages from tool result messages
            conversational = []
            for msg in raw_history:
                content = str(msg).lower()
                # Keep messages that are conversational context
                # Skip messages that are just tool execution reports
                is_tool_noise = any(phrase in content for phrase in [
                    "spreadsheetid",
                    "docs.google.com/spreadsheets",
                    "maton_gateway",
                    "tool call",
                ])
                if not is_tool_noise:
                    conversational.append(msg)

            # If history is long, summarize older messages
            if len(conversational) > 10:
                # Keep last 6 messages verbatim
                recent = conversational[-6:]
                older_count = len(conversational) - 6
                # Build a summary placeholder
                summary = {
                    "role": "user",
                    "content": f"[Context summary: This conversation has {older_count} earlier messages. The user has been working with this agent on various tasks.]"
                }
                message_history = [summary] + recent
            else:
                message_history = conversational

            # Auto-truncate if context window gets too large
            if estimate_tokens(message_history) > 8000:
                logger.info({
                    "event": "context_truncated",
                    "run_id": run_id,
                    "reason": "token_limit",
                })
                message_history = message_history[-4:]

            logger.info({
                "event": "history_loaded",
                "run_id": run_id,
                "thread_id": thread_id,
                "raw_count": len(raw_history),
                "used_count": len(message_history),
            })

        # Get memory context and inject into system prompt
        memory_context = await format_memory_context(db, agent_id)

        # Build agent identity block — tells LLM who it is, what it does,
        # and what role it plays. This goes BEFORE global prefix so that
        # identity is the strongest signal in the context.
        identity_lines = [f"You are {agent.name}, an AI agent."]
        if agent.description and agent.description.strip():
            identity_lines.append(f"Your purpose: {agent.description.strip()}")
        role_descriptions = {
            "standalone": "You operate independently and handle user requests end-to-end.",
            "coordinator": "You are a coordinator agent. You delegate work to worker agents when appropriate, using list_agents and trigger_run tools.",
            "worker": "You are a worker agent. You handle specific tasks delegated to you and report results clearly.",
        }
        if agent.role in role_descriptions:
            identity_lines.append(role_descriptions[agent.role])

        identity_block = "## Your identity\n" + "\n".join(identity_lines)

        # User-defined system prompt (the "instructions" field user typed in
        # Edit Agent dialog)
        user_instructions = agent.system_prompt or ""
        if user_instructions.strip():
            user_instructions_block = f"## Your instructions\n{user_instructions.strip()}"
        else:
            user_instructions_block = ""

        # Assemble: identity → user instructions → global rules
        system_prompt_parts = [identity_block]
        if user_instructions_block:
            system_prompt_parts.append(user_instructions_block)
        system_prompt_parts.append(GLOBAL_PREFIX)
        system_prompt = "\n\n".join(system_prompt_parts)
        if memory_context:
            system_prompt = f"{system_prompt}\n\n{memory_context}"
            logger.debug({"event": "run_agent", "agent_id": agent_id, "has_memory": True})

        from app.services.approval_service import get_approval, list_approvals
        pending_approvals = []
        if parent_run_id:
            # Check if this run has any unapproved approvals
            result = await list_approvals(
                db=db,
                user_id=user_id,
                status="pending",
                limit=100,
            )
            for approval in result:
                if approval.run_id == parent_run_id:
                    pending_approvals.append(approval)
                    logger.info({
                        "event": "pending_approval_found",
                        "approval_id": str(approval.id),
                        "parent_run_id": parent_run_id,
                    })
        elif run_id:
            # Check for approvals requested by this run
            result = await list_approvals(
                db=db,
                user_id=user_id,
                status="pending",
                limit=100,
            )
            for approval in result:
                if approval.run_id == run_id:
                    pending_approvals.append(approval)
                    logger.info({
                        "event": "run_pending_approval_found",
                        "approval_id": str(approval.id),
                        "run_id": run_id,
                    })
                    break  # No need to check more if we found one

        # If there are pending approvals, pause execution
        if pending_approvals:
            await update_run(
                db=db,
                run_id=run_id,
                status="awaiting_approval",
            )
            logger.info({
                "event": "run_paused_for_approval",
                "run_id": run_id,
                "approval_count": len(pending_approvals),
            })

        # Load user's configured external tools for context
        external_tools_result = await db.execute(
            select(Tool).where(
                Tool.user_id == user_id,
                Tool.source.in_(['composio', 'apify', 'maton']),
                Tool.is_active == True,
            )
        )
        external_tools = external_tools_result.scalars().all()

        if external_tools:
            tool_context = "\n\n## Your configured external tools:\n"
            for tool in external_tools:
                if tool.source == 'maton':
                    app_name = tool.config.get("app", "google-sheet")
                    # Maton gateway tools use underscore format (e.g., google_sheet_create_spreadsheet)
                    # These are async Python functions that call Maton's gateway HTTP API directly
                    # No check_connection workflow needed - gateway tools can be called immediately
                    if app_name in ("google-sheet", "google-sheets"):
                        tool_context += (
                            "- Google Sheets (Maton): "
                            "google_sheet_create_spreadsheet(title), "
                            "google_sheet_append_rows(spreadsheet_id, values, range), "
                            "google_sheet_get_values(spreadsheet_id, range), "
                            "google_sheet_update_values(spreadsheet_id, range, values), "
                            "google_sheet_get_spreadsheet(spreadsheet_id).\n"
                            "  WORKFLOW: After create_spreadsheet succeeds:\n"
                            "  1. Call set_memory(key='{title}_url', value=spreadsheetUrl)\n"
                            "  2. Call set_memory(key='{title}_id', value=spreadsheetId)\n"
                            "  3. Include the URL in your response text\n"
                            "  Default sheet name is 'Hoja 1' (Spanish locale).\n"
                        )
                    else:
                        tool_context += (
                            f"- Google Sheets (Maton): google_sheet_create_spreadsheet(title), "
                            f"google_sheet_append_rows(spreadsheet_id, range, values), "
                            f"google_sheet_get_values(spreadsheet_id, range), "
                            f"google_sheet_update_values(spreadsheet_id, range, values), "
                            f"google_sheet_get_spreadsheet(spreadsheet_id).\n"
                            f"NOTE: Default range for appending is 'Hoja 1!A1' (Spanish locale), not 'Sheet1!A1'. "
                            f"Workflow: 1) create_spreadsheet, 2) append_rows with range='Hoja 1!A1'.\n"
                        )
                elif tool.source == 'composio':
                    toolkits = tool.config.get("toolkits", [])
                    if toolkits:
                        toolkit_names = ", ".join(toolkits[:3])
                        if len(toolkits) > 3:
                            toolkit_names += f", and {len(toolkits) - 3} more"
                        tool_context += f"- Composio: Access {toolkit_names} tools. Use the appropriate tools for each service.\n"
                    else:
                        tool_context += f"- Composio: Access your connected business tools. Search and use the available tools dynamically.\n"
                elif tool.source == 'apify':
                    tools_config = tool.config.get("tools", "")
                    tool_context += f"- Apify: Web scraping and data extraction. Use apify_* tools like search-actors, call-actor, and apify-slash-rag-web-browser for web browsing.\n"
            system_prompt += tool_context
            logger.debug({"event": "external_tools_context", "count": len(external_tools)})

        # List the agent's actually-granted tools by name so LLM knows
        # what's in its toolbox without having to discover them.
        if tools:
            granted_tool_names = []
            for t in tools:
                name = getattr(t, "__name__", None) or getattr(t, "name", None) or str(t)
                if name and name not in granted_tool_names:
                    granted_tool_names.append(name)
            if granted_tool_names:
                system_prompt += "\n\n## Your available tools\n"
                system_prompt += "You have access to these tools — use them when relevant:\n"
                for name in granted_tool_names:
                    system_prompt += f"- {name}\n"

        # Add self-call capabilities context
        system_prompt += """

## IMPORTANT — How to behave:
- When a user asks you to DO something (send a message, trigger a workflow,
  create a schedule, save a memory), USE THE TOOL IMMEDIATELY. Do not ask
  for confirmation unless critical information is missing.
- When a user mentions "maton", "maton.ai", "workflow", or any variation,
  call trigger_maton_workflow directly.
- When a user asks you to remember something, call set_memory immediately.
- When a user asks to schedule something, call create_schedule immediately.
- Integration setup: ALWAYS call resolve_integration before creating or configuring
  any Maton/Composio/Apify integration. Show the confirmation_message
  to the user and wait for their confirmation before proceeding. If confidence is "low",
  show the clarification_message instead and wait for the user to clarify.
- You have the following platform capabilities — use them proactively:
  - Schedules: create_schedule, list_schedules, pause_schedule, resume_schedule, delete_schedule
  - Memory: get_memory, set_memory, delete_memory
  - Runs: trigger_run, get_run_status, list_runs
  - Threads: list_threads, get_thread_messages
  - Agents: list_agents, get_agent_by_name, get_agent
  - Integration Setup: resolve_integration
"""
        logger.debug({"event": "self_call_context_added"})

        # Emit "thinking" indicator
        await stream_progress("🤔 Thinking...")

        # Set API keys as environment variables for PydanticAI
        # PydanticAI automatically uses OPENAI_API_KEY, ANTHROPIC_API_KEY, GEMINI_API_KEY, etc.
        if model_api_keys:
            for provider, key in model_api_keys.items():
                # Google provider uses GEMINI_API_KEY (not GOOGLE_API_KEY)
                env_var_name = "GEMINI_API_KEY" if provider == "google" else f"{provider.upper()}_API_KEY"
                original_value = os.environ.get(env_var_name, "")
                saved_env_vars[env_var_name] = original_value
                os.environ[env_var_name] = key

        # Create PydanticAI agent
        logger.info({"event": "run_agent", "run_id": run_id, "agent_id": agent_id, "status": "creating_agent"})

        # PydanticAI expects model as string like "openai:gpt-4o" or Model object
        # For Google GLA (provider='google'), we need to create a GeminiModel object
        if agent.model_provider == "google":
            # Create GeminiModel with google-gla provider
            # GEMINI_API_KEY environment variable is set above (line 99)
            model_obj = GeminiModel(agent.model_id, provider='google-gla')
        elif agent.model_provider == "openai":
            model_obj = f"openai:{agent.model_id}"
        elif agent.model_provider == "anthropic":
            model_obj = f"anthropic:{agent.model_id}"
        elif agent.model_provider == "ollama":
            model_obj = f"ollama:{agent.model_id}"
        elif agent.model_provider == "openrouter":
            model_obj = f"openrouter:{agent.model_id}"
        elif agent.model_provider == "mistral":
            model_obj = f"mistral:{agent.model_id}"
        elif agent.model_provider == "xai":
            model_obj = f"xai:{agent.model_id}"
        elif agent.model_provider == "qwen":
            model_obj = f"qwen:{agent.model_id}"
        elif agent.model_provider == "deepseek":
            model_obj = f"deepseek:{agent.model_id}"
        elif agent.model_provider == "zai":
            model_obj = f"zai:{agent.model_id}"
        else:
            model_obj = agent.model_id

        # Create agent with PydanticAI
        # PydanticAI automatically picks up API keys from env vars (OPENAI_API_KEY, GEMINI_API_KEY, etc.)
        pydantic_agent = PydanticAgent(
            model_obj,
            tools=tools,
            toolsets=mcp_servers,  # MCP servers go here
            system_prompt=system_prompt,
        )

        # Run the agent with streaming
        logger.info({"event": "run_agent", "run_id": run_id, "agent_id": agent_id, "status": "executing"})

        # Emit "using tools" indicator
        await stream_progress("🔧 Using tools...")

        # Prepare run kwargs with message history if available
        run_kwargs = {"deps": None}
        if agent.temperature is not None:
            run_kwargs["model_settings"] = {"temperature": float(agent.temperature)}
        if message_history:
            # CRITICAL: Convert plain dicts to PydanticAI ModelMessage objects
            # PydanticAI's message_history expects Sequence[ModelRequest | ModelResponse]
            # NOT plain dicts with role/content keys
            pydantic_message_history = convert_to_pydantic_messages(message_history)

            # Log what is actually being passed to PydanticAI
            logger.info({
                "event": "history_passed_to_agent",
                "run_id": run_id,
                "message_count": len(pydantic_message_history),
                "first_message_type": type(pydantic_message_history[0]).__name__ if pydantic_message_history else None,
                "sample": str(pydantic_message_history[0])[:100] if pydantic_message_history else None,
            })

            run_kwargs["message_history"] = pydantic_message_history

        # Use async context manager to properly start/stop MCP servers
        async with pydantic_agent.run_mcp_servers():
            result = await pydantic_agent.run(input_text, **run_kwargs)

        # TRACE 5: Log full message history including all tool calls and responses
        logger.info({"event": "agent_trace_start_history", "run_id": run_id})
        try:
            for msg in result.all_messages():
                for part in getattr(msg, "parts", []):
                    kind = getattr(part, "part_kind", type(part).__name__)
                    if kind == "tool-call":
                        tool_name = getattr(part, "tool_name", None)
                        logger.info({
                            "event": "agent_tool_call",
                            "run_id": run_id,
                            "tool_name": tool_name,
                            "args": part.args_as_dict() if hasattr(part, "args_as_dict") else str(getattr(part, "args", "")),
                        })

                        # Check for approval request
                        if tool_name == "request_approval":
                            # Extract approval data from tool arguments
                            args_dict = part.args_as_dict() if hasattr(part, "args_as_dict") else {}
                            kind = args_dict.get("kind", "execute_action")
                            title = args_dict.get("title", "Agent action requires approval")
                            description = args_dict.get("description", "No description provided")
                            payload = args_dict.get("payload", {})

                            # Create approval record
                            approval_id = await create_approval(
                                db=db,
                                user_id=user_id,
                                agent_id=agent_id,
                                run_id=run_id,
                                schedule_id=None,
                                kind=kind,
                                title=title,
                                description=description,
                                payload=payload,
                            )

                            # Update run status to awaiting_approval
                            await update_run(
                                db=db,
                                run_id=run_id,
                                status="awaiting_approval",
                            )

                            # Stream approval requested message
                            await stream_progress(f"🔔 Approval requested: {title}")

                            # Stream completion message with approval details
                            await stream_message({
                                "type": "approval_requested",
                                "approval_id": approval_id,
                                "kind": kind,
                                "title": title,
                                "description": description,
                            })

                            logger.info({
                                "event": "approval_created",
                                "approval_id": approval_id,
                                "run_id": run_id,
                                "kind": kind,
                            })

                            # Stop execution - output will be set to awaiting_approval
                            return None
                    elif kind == "tool-return":
                        content_str = str(getattr(part, "content", ""))[:500]
                        logger.info({
                            "event": "agent_tool_return",
                            "run_id": run_id,
                            "tool_name": getattr(part, "tool_name", None),
                            "content": content_str,
                        })
                    elif kind in ("user-prompt", "text", "system-prompt"):
                        logger.debug({
                            "event": "agent_message_part",
                            "run_id": run_id,
                            "kind": kind,
                            "content_preview": str(getattr(part, "content", ""))[:200],
                        })
        except Exception as history_err:
            logger.warning({
                "event": "agent_history_log_failed",
                "error": str(history_err),
            })

        # Stream the output
        output_text = result.output
        await stream_token(output_text)

        # Enrich saved message with tool results for future context
        tool_results = extract_tool_results(result.all_messages())

        # Only append if tool results contain something not already in output
        # (avoids duplication if agent already mentioned the URL)
        saved_output = output_text
        if tool_results:
            # Check if key info (spreadsheet IDs, URLs) is already in output
            has_url = "docs.google.com" in output_text or "spreadsheetId" in output_text
            if not has_url:
                saved_output = output_text + "\n" + tool_results
            logger.debug({
                "event": "tool_results_extracted",
                "run_id": run_id,
                "has_url_in_output": has_url,
                "tool_results_preview": tool_results[:100] if len(tool_results) > 100 else tool_results,
            })

        # Cache full output in Redis FIRST so late SSE consumers can always replay.
        # Must happen before done event so consumer's empty-list fallback always finds something.
        try:
            await redis.setex(
                f"ocin:run:{run_id}:output",
                300,
                json.dumps({"type": "done", "output": saved_output, "run_id": run_id})
            )
            logger.debug({"event": "output_cached", "run_id": run_id})
        except Exception as e:
            logger.warning({"event": "cache_output_failed", "run_id": run_id, "error": str(e)})

        # Now publish done event. Any consumer reading the list will see this;
        # any consumer that arrives later will hit the cache fallback.
        await stream_message({
            "type": "done",
            "run_id": run_id,
            "status": "success",
        })

        # Calculate metrics
        duration_ms = int((time.time() - start_time) * 1000)
        usage = result.usage() if hasattr(result, "usage") else None
        tokens_used = usage.total_tokens if usage and hasattr(usage, "total_tokens") else 0

        # Update run record
        await update_run(
            db,
            run_id,
            status="success",
            output=saved_output,  # ← use saved_output not output_text
            tool_calls=[],  # Tool calls are embedded in output
            tokens_used=tokens_used,
            cost_usd=0.0,  # TODO: calculate based on model pricing
            finished_at=datetime.utcnow(),
        )

        logger.info({
            "event": "run_agent_complete",
            "run_id": run_id,
            "agent_id": agent_id,
            "status": "success",
            "tokens_used": tokens_used,
            "duration_ms": duration_ms,
        })

        # Extract and save memory if output is long enough (runs in background)
        # Use saved_output so memory includes tool results (URLs, IDs, etc.)
        if len(saved_output.strip()) >= 100:
            try:
                await extract_and_save_memory(db, agent_id, input_text, saved_output)
            except Exception as e:
                logger.warning({"event": "memory_extraction_failed", "error": str(e)})

        # Save messages to thread if thread_id is provided
        if thread_id:
            try:
                await save_messages(db, thread_id, input_text, saved_output)
                logger.info({"event": "messages_saved", "thread_id": thread_id})
            except Exception as e:
                logger.warning({"event": "save_messages_failed", "error": str(e)})

        return output_text

    except Exception as e:
        duration_ms = int((time.time() - start_time) * 1000)

        # Push friendly error to SSE stream so client can render it
        from app.core.errors import friendly_llm_error
        friendly = friendly_llm_error(str(e))
        stream_key = f"ocin:run:{run_id}:stream"
        await redis.rpush(stream_key, json.dumps({
            "type": "error",
            "run_id": run_id,
            "category": friendly["category"],
            "message": friendly["message"],
        }))
        await redis.expire(stream_key, 600)
        # Update run record with error
        await update_run(
            db,
            run_id,
            status="failed",
            error=str(e),
            finished_at=datetime.utcnow(),
        )

        logger.error({
            "event": "run_agent_error",
            "run_id": run_id,
            "agent_id": agent_id,
            "error": str(e),
            "duration_ms": duration_ms,
        })
        return None

    finally:
        # Clear self-call context
        if jwt_token:
            clear_self_call_context()
            logger.debug({"event": "cleared_self_call_context"})

        # Close MCP servers
        for server in mcp_servers:
            try:
                if hasattr(server, 'close'):
                    await server.close()
            except Exception as e:
                logger.warning({"event": "cleanup_mcp_server", "error": str(e)})

        # Clean up legacy clients (now empty)
        for client in tools_data.get("clients", []):
            try:
                await client.close()
            except Exception as e:
                logger.warning({"event": "cleanup_client", "error": str(e)})

        # Restore original environment variables (only those we modified)
        for env_var_name, original_value in saved_env_vars.items():
            os.environ[env_var_name] = original_value
