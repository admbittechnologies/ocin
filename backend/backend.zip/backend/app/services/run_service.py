import logging
from datetime import datetime
from typing import Optional

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel

from app.models.run import Run
from app.models.agent import Agent

logger = logging.getLogger("ocin")


class RunCreate(BaseModel):
    user_id: str
    agent_id: str
    schedule_id: Optional[str] = None
    input: str
    status: str = "pending"


async def create_run(
    db: AsyncSession,
    run_data: RunCreate,
) -> Run:
    """Create a new run record."""
    run = Run(
        user_id=run_data.user_id,
        agent_id=run_data.agent_id,
        schedule_id=run_data.schedule_id,
        input=run_data.input,
        status=run_data.status,
    )
    db.add(run)
    await db.commit()
    await db.refresh(run)

    logger.info({"event": "create_run", "run_id": str(run.id), "agent_id": run.agent_id})
    return run


async def update_run(
    db: AsyncSession,
    run_id: str,
    status: Optional[str] = None,
    output: Optional[str] = None,
    tool_calls: Optional[list] = None,
    tokens_used: Optional[int] = None,
    cost_usd: Optional[float] = None,
    error: Optional[str] = None,
    started_at: Optional[datetime] = None,
    finished_at: Optional[datetime] = None,
    parent_run_id: Optional[str] = None,  # New child run for continuation
) -> Optional[Run]:
    """Update a run record.

    Args:
        db: Database session
        run_id: The run ID
        status: Optional new status (pending | running | success | failed | awaiting_approval)
        output: Optional new output
        tool_calls: Optional new tool call list
        tokens_used: Optional new token count
        cost_usd: Optional new cost
        error: Optional new error message
        started_at: Optional new start time
        finished_at: Optional new finish time
        parent_run_id: Optional parent run ID for continuation

    Returns:
        Updated Run object or None if not found

    Status Change Support:
        When setting status="awaiting_approval", run is paused but not blocked.
        When setting status="running", run continues from awaiting_approval state.
        When setting status="success", run completes normally.
        When setting status="failed" or "awaiting_approval", run is blocked and doesn't auto-continue.
    """
    result = await db.execute(select(Run).where(Run.id == run_id))
    run = result.scalar_one_or_none()

    if not run:
        return None

    # Apply status update if provided
    if status is not None:
        run.status = status
    if output is not None:
        run.output = output
    if tool_calls is not None:
            run.tool_calls = tool_calls
    if tokens_used is not None:
            run.tokens_used = tokens_used
    if cost_usd is not None:
            run.cost_usd = cost_usd
    if error is not None:
            run.error = error
    if started_at is not None:
        run.started_at = started_at
    if finished_at is not None:
        run.finished_at = finished_at

    await db.commit()
    await db.refresh(run)

    logger.info({"event": "update_run", "run_id": str(run.id), "status": run.status})

    return run
    """Update a run record."""
    result = await db.execute(select(Run).where(Run.id == run_id))
    run = result.scalar_one_or_none()

    if not run:
        return None

    if status is not None:
        run.status = status
    if output is not None:
        run.output = output
    if tool_calls is not None:
        run.tool_calls = tool_calls
    if tokens_used is not None:
        run.tokens_used = tokens_used
    if cost_usd is not None:
        run.cost_usd = cost_usd
    if error is not None:
        run.error = error
    if started_at is not None:
        run.started_at = started_at
    if finished_at is not None:
        run.finished_at = finished_at

    await db.commit()
    await db.refresh(run)

    logger.info({"event": "update_run", "run_id": str(run.id), "status": run.status})
    return run


async def list_runs(
    db: AsyncSession,
    user_id: str,
    skip: int = 0,
    limit: int = 50,
    agent_id: Optional[str] = None,
    status: Optional[str] = None,
) -> list[Run]:
    """List runs for a user."""
    query = select(Run).where(Run.user_id == user_id)
    if agent_id:
        query = query.where(Run.agent_id == agent_id)
    if status:
        query = query.where(Run.status == status)
    query = query.order_by(Run.started_at.desc().nullslast()).offset(skip).limit(limit)
    result = await db.execute(query)
    return list(result.scalars().all())


async def get_run(db: AsyncSession, run_id: str, user_id: str) -> Optional[Run]:
    """Get a run by ID (user-scoped)."""
    result = await db.execute(
        select(Run).where(Run.id == run_id, Run.user_id == user_id)
    )
    return result.scalar_one_or_none()
