import logging
from typing import Optional
from app.postgrest_client import get_postgrest_client
from app.core.security import hash_password

logger = logging.getLogger("ocin")


async def create_user(email: str, password: str) -> dict:
    """Create a new user using PostgREST."""
    client = get_postgrest_client()

    # Check if user already exists
    existing = await client.get_by_id("users", f"eq.{email}")
    if existing:
        logger.warning({"event": "create_user", "email": email, "error": "User already exists"})
        raise ValueError("User with this email already exists")

    user_data = {
        "email": email,
        "hashed_password": hash_password(password),
        "plan": "free"
    }

    try:
        user = await client.create("users", user_data)
        logger.info({"event": "create_user", "user_id": user.get("id"), "email": email})
        return user
    except Exception as e:
        logger.error({"event": "create_user_error", "email": email, "error": str(e)})
        raise


async def get_user_by_email(email: str) -> Optional[dict]:
    """Get a user by email using PostgREST."""
    client = get_postgrest_client()

    users = await client.get_all("users", filters={"email": f"eq.{email}"}, limit=1)
    if users and len(users) > 0:
        return users[0]
    return None


async def get_user_by_id(user_id: str) -> Optional[dict]:
    """Get a user by ID using PostgREST."""
    client = get_postgrest_client()

    return await client.get_by_id("users", user_id)