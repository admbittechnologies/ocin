import logging
import time
import os
import re
import functools
from datetime import datetime
from typing import Any
import json

from app.postgrest_client import get_postgrest_client
from pydantic_ai import Agent as PydanticAgent
from pydantic import BaseModel as PydanticBaseModel
from pydantic_ai.models.gemini import GeminiModel
from pydantic_ai.messages import ModelRequest, ModelResponse, UserPromptPart, TextPart

from app.models.run import Run
from app.models.agent import Agent as AgentModel
from app.models.tool import Tool
from app.services.tool_loader import build_tools_for_agent
from app.services.run_service import update_run, create_run
from app.services.thread_service import save_messages, get_thread_messages_for_context
from app.services.memory_extraction import extract_and_save_memory, format_memory_context
from app.services.approval_service import create_approval
from app.core.exceptions import ToolUnavailableException
from app.config import settings
from app.integrations.self_tools import set_self_call_context, clear_self_call_context, get_self_tools

logger = logging.getLogger("ocin")

BaseModel = PydanticBaseModel

def estimate_tokens(messages: list) -> int:
    """Rough token estimate: ~4 chars per token."""
    total_chars = sum(len(str(m)) for m in messages)
    return total_chars // 4


def convert_to_pydantic_messages(raw_messages: list) -> list[ModelRequest | ModelResponse]:
    """Convert plain dict messages to PydanticAI ModelMessage objects.

    Args:
        raw_messages: List of dicts with 'role' and 'content' keys

    Returns:
        List of ModelRequest (for user messages) or ModelResponse (for assistant messages)
    """
    PydanticAI's message_history parameter expects a sequence of ModelRequest
    and ModelResponse objects, not plain dicts. This function handles
    conversion.

    converted_messages = []
    for msg in raw_messages:
        if msg.get('role') == 'user':
            converted_messages.append(
                ModelRequest(
                    role='user',
                    content=[TextPart(type='text', text=msg.get('content', 'value'))]
                )
            )
        else:  # Assistant or system message
            converted_messages.append(
                ModelResponse(
                    role='assistant',
                    content=[TextPart(type='text', text=msg.get('content', 'value'))]
                )
            )
    return converted_messages


async def execute_agent(agent_id: str, input: str) -> dict:
    """
    Execute an agent run with PydanticAI.

    Args:
        agent_id: ID of the agent to run
        input: User input/prompt for the agent

    Returns:
        Dict with run results including output, tool calls, tokens, cost
    """
    start_time = time.time()
    logger.info({
        "event": "agent_execution_start",
        "agent_id": agent_id,
        "input": input
    })

    # Get agent configuration from PostgREST
    client = get_postgrest_client()

    try:
        # Get agent by ID
        agents = await client.get_all(
            "agents",
            filters={"id": f"eq.{agent_id}"},
            limit=1
        )

        if not agents or len(agents) == 0:
            raise Exception(f"Agent {agent_id} not found")

        agent_config = agents[0]
        logger.info({
            "event": "agent_loaded",
            "agent_id": agent_id,
            "name": agent_config.get("name"),
            "model_provider": agent_config.get("model_provider"),
            "model_id": agent_config.get("model_id")
        })

        # Get user's encrypted API keys from tools
        user_id = agent_config.get("user_id")
        tools_filter = f"user_id.eq.{user_id}"
        tools = await client.get_all("tools", filters={"is_active": "eq.true", tools_filter})

        # Decrypt API keys and build tool configurations
        tool_configs = []
        for tool in tools:
            config = tool.get("config", {})
            if not isinstance(config, dict):
                logger.warning(f"Invalid config format for tool {tool.get('id')}")
                continue

            # Decrypt tool API key if present
            tool_api_key = None
            if tool.get("source") in ["composio"]:
                # TODO: Decrypt Composio API key from Fernet
                tool_api_key = config.get("composio_api_key", "")
                logger.info(f"Using Composio API key for tool {tool.get('name')}")
            elif tool.get("source") in ["apify"]:
                # TODO: Apify token is used directly
                logger.info(f"Using Apify for tool {tool.get('name')}")
            elif tool.get("source") in ["maton"]:
                # TODO: Maton uses gateway directly
                logger.info(f"Using Maton gateway for tool {tool.get('name')}")

            if tool_api_key:
                tool_config["api_key"] = tool_api_key

            tool_configs.append({
                "id": tool.get("id"),
                "name": tool.get("name"),
                "source": tool.get("source"),
                "config": tool_config
            })

        logger.info({
            "event": "tools_loaded",
            "agent_id": agent_id,
            "tool_count": len(tool_configs)
        })

        # Build PydanticAI tools list
        pydantic_tools = build_tools_for_agent(tool_configs)
        logger.info({
            "event": "pydantic_tools_built",
            "agent_id": agent_id,
            "tool_count": len(pydantic_tools)
        })

        # Initialize agent with messages
        system_prompt = agent_config.get("system_prompt") or "You are a helpful assistant."

        # If thread_id is provided, get previous messages for context
        # This would require a thread lookup - simplify for now

        messages = [
            ModelRequest(role='user', content=[TextPart(type='text', text=input)])
        ]

        # Initialize PydanticAI agent
        if agent_config.get("model_provider") == "openai":
            model_client = openai.AsyncOpenAI(api_key=settings.OPENAI_API_KEY)
            agent = PydanticAgent(model_id=agent_config.get("model_id"), tools=pydantic_tools)
        elif agent_config.get("model_provider") == "anthropic":
            model_client = anthropic.AsyncAnthropic(api_key=settings.ANTHROPIC_API_KEY)
            agent = PydanticAgent(model_id=agent_config.get("model_id"), tools=pydantic_tools)
        elif agent_config.get("model_provider") == "google":
            model_client = genai.AsyncClient(api_key=settings.GOOGLE_API_KEY)
            agent = PydanticAgent(model_id=agent_config.get("model_id"), tools=pydantic_tools)
        elif agent_config.get("model_provider") == "ollama":
            # Connect to local Ollama instance
            model_client = ollama.AsyncClient(base_url=settings.OLLAMA_BASE_URL)
            agent = PydanticAgent(model_id=agent_config.get("model_id"), tools=pydantic_tools)
        else:
            raise Exception(f"Unsupported model provider: {agent_config.get('model_provider')}")

        # Execute agent
        result = await agent.run(messages)

        execution_time = time.time() - start_time

        logger.info({
            "event": "agent_execution_complete",
            "agent_id": agent_id,
            "execution_time": execution_time,
            "output_length": len(result.content) if result.content else 0
        })

        return {
            "run_id": None,
            "output": result.content,
            "tool_calls": [],
            "tokens_used": 0,
            "cost": 0.0
        }