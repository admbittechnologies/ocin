import logging
import re
from datetime import datetime
from typing import Optional

from app.postgrest_client import get_postgrest_client
from app.schemas.schedule import ScheduleCreate, ScheduleUpdate
from pydantic import BaseModel, Field
from app.core.system_model import run_system_task

logger = logging.getLogger("ocin")


def _simple_parse_schedule(label: str) -> str:
    """Simple regex-based cron parser fallback when LLM is unavailable.

    Supports basic patterns:
    - "every minute" -> "* * * * *"
    - "every 5 minutes" -> "*/5 * * * *"
    - "every day" -> "0 0 * * *"
    - "every day at 9am" -> "0 9 * * *"
    - "daily" -> "0 0 * * *"
    - "hourly" -> "0 * * * *"
    """
    text = label.strip().lower()

    # Every minute patterns
    if re.match(r'^every\s+minute\b', text):
        return "* * * * *"
    if re.match(r'^every\s+\d+\s+minutes?\b', text):
        match = re.search(r'\d+', text)
        if match:
            mins = match.group()
            return f"*/{mins} * * * *"
    # Every day patterns
    if re.match(r'^every\s+day\b', text):
        return "0 0 * * *"
    if re.match(r'^every\s+day\s+at\s+\d+am\b', text):
        return f"0 {mins} * * *"
    if re.match(r'^daily\b', text):
        return "0 0 * * *"
    if re.match(r'^hourly\b', text):
        return "0 * * * *"

    return None  # LLM will parse to cron


async def create_schedule(user_id: str, agent_id: str, label: str, cron_expression: str = None, input: str = None) -> dict:
    """
    Create a new schedule using PostgREST.

    Args:
        user_id: ID of the user creating the schedule
        agent_id: ID of the agent to run
        label: User-friendly description (e.g., "Every morning at 9")
        cron_expression: Optional cron expression if user provided one
        input: What the agent should do each time it runs

    Returns:
        Created schedule record as dictionary
    """
    client = get_postgrest_client()

    schedule_data = {
        "user_id": user_id,
        "agent_id": agent_id,
        "label": label,
        "trigger_type": "cron",
        "payload": {"input": input} if input else {},
        "is_active": True
    }

    try:
        schedule = await client.create("schedules", schedule_data)
        logger.info({
            "event": "schedule_created",
            "schedule_id": schedule.get("id"),
            "label": label,
            "user_id": user_id,
            "agent_id": agent_id
        })
        return schedule
    except Exception as e:
        logger.error({
            "event": "schedule_create_error",
            "user_id": user_id,
            "agent_id": agent_id,
            "label": label,
            "error": str(e)
        })
        raise


async def get_schedules(user_id: str) -> list[dict]:
    """
    Get all schedules for a user using PostgREST.

    Args:
        user_id: ID of the user

    Returns:
        List of schedule records as dictionaries
    """
    client = get_postgrest_client()

    try:
        schedules = await client.get_all(
            "schedules",
            filters={"user_id": f"eq.{user_id}"},
            order="created_at.desc"
        )
        logger.info({
            "event": "schedules_retrieved",
            "user_id": user_id,
            "count": len(schedules)
        })
        return schedules
    except Exception as e:
        logger.error({
            "event": "schedules_retrieval_error",
            "user_id": user_id,
            "error": str(e)
        })
        raise


async def update_schedule(schedule_id: str, label: str = None, cron_expression: str = None, input: str = None, is_active: bool = True) -> dict:
    """
    Update an existing schedule using PostgREST.

    Args:
        schedule_id: ID of the schedule to update
        label: Optional new label for the schedule
        cron_expression: Optional new cron expression
        input: Optional new input for the agent
        is_active: Whether the schedule should be active

    Returns:
        Updated schedule record as dictionary
    """
    client = get_postgrest_client()

    update_data = {}
    if label:
        update_data["label"] = label
    if cron_expression:
        update_data["cron_expression"] = cron_expression
    if input:
        update_data["payload"] = {"input": input}
    update_data["is_active"] = is_active

    try:
        updated_schedule = await client.update("schedules", schedule_id, update_data)
        logger.info({
            "event": "schedule_updated",
            "schedule_id": schedule_id,
            "updates": list(update_data.keys())
        })
        return updated_schedule
    except Exception as e:
        logger.error({
            "event": "schedule_update_error",
            "schedule_id": schedule_id,
            "error": str(e)
        })
        raise


async def delete_schedule(schedule_id: str) -> bool:
    """
    Delete a schedule using PostgREST.

    Args:
        schedule_id: ID of the schedule to delete

    Returns:
        True if deleted successfully
    """
    client = get_postgrest_client()

    try:
        await client.delete("schedules", schedule_id)
        logger.info({
            "event": "schedule_deleted",
            "schedule_id": schedule_id
        })
        return True
    except Exception as e:
        logger.error({
            "event": "schedule_delete_error",
            "schedule_id": schedule_id,
            "error": str(e)
        })
        raise