"""
PostgREST client wrapper for OCIN backend.
Handles authentication, connection management, and CRUD operations.
"""
import httpx
import logging
from typing import Optional, Dict, List, Any
from app.config import settings

logger = logging.getLogger("ocin")
import logging
from typing import Optional, Dict, List, Any
from app.config import settings

logger = logging.getLogger("ocin")


class PostgRESTClient:
    """
    PostgREST client for making HTTP requests to PostgREST server.
    """

    def __init__(
        self,
        base_url: str = None,
        api_key: str = None,
        schema: str = "public"
    ):
        """
        Initialize PostgREST client.

        Args:
            base_url: PostgREST server URL (defaults to settings.POSTGREST_URL)
            api_key: Service role key for authentication (defaults to settings.POSTGREST_API_KEY)
            schema: Database schema to use (defaults to "public")
        """
        self.base_url = (base_url or settings.POSTGREST_URL).rstrip("/")
        self.api_key = api_key or settings.POSTGREST_API_KEY
        self.schema = schema
        self.headers = {
            "apikey": self.api_key,
            "Content-Type": "application/json",
            "Prefer": "return=representation"
        }

        # Create async HTTP client
        self.client = httpx.AsyncClient(
            base_url=self.base_url,
            headers=self.headers,
            timeout=httpx.Timeout(30.0, connect=10.0)
        )

        logger.info({
            "event": "postgrest_client_init",
            "base_url": self.base_url,
            "schema": self.schema
        })

    def _build_url(self, table: str, id: Optional[str] = None) -> str:
        """Build full URL for a table or specific record."""
        url = f"/{self.schema}/{table}"
        if id:
            url += f"/{id}"
        return url

    async def get_all(
        self,
        table: str,
        filters: Optional[Dict[str, Any]] = None,
        order: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """
        Get all records from a table with optional filtering.

        Args:
            table: Database table name
            filters: Dict of filter conditions (e.g., {"user_id": "eq.123"})
            order: Order by clause (e.g., "created_at.desc")
            limit: Maximum number of records to return
            offset: Number of records to skip

        Returns:
            List of records as dictionaries
        """
        url = self._build_url(table)
        params = {}

        if filters:
            filter_str = " and ".join(
                f"{k}={v}" for k, v in filters.items()
            )
            params["select"] = "*"
            params["and"] = f"({filter_str})"
        else:
            params["select"] = "*"

        if order:
            params["order"] = order
        if limit:
            params["limit"] = str(limit)
        if offset:
            params["offset"] = str(offset)

        try:
            response = await self.client.get(url, params=params)
            response.raise_for_status()
            return response.json()
        except httpx.HTTPStatusError as e:
            logger.error({
                "event": "postgrest_get_all_error",
                "table": table,
                "status_code": e.response.status_code,
                "error": str(e)
            })
            raise
        except Exception as e:
            logger.error({
                "event": "postgrest_get_all_exception",
                "table": table,
                "error": str(e)
            })
            raise

    async def get_by_id(self, table: str, id: str) -> Optional[Dict[str, Any]]:
        """
        Get a single record by ID.

        Args:
            table: Database table name
            id: Record ID

        Returns:
            Record as dictionary or None if not found
        """
        url = self._build_url(table, id)

        try:
            response = await self.client.get(url)
            if response.status_code == 404:
                return None
            response.raise_for_status()
            return response.json()
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 404:
                return None
            logger.error({
                "event": "postgrest_get_by_id_error",
                "table": table,
                "id": id,
                "status_code": e.response.status_code,
                "error": str(e)
            })
            raise
        except Exception as e:
            logger.error({
                "event": "postgrest_get_by_id_exception",
                "table": table,
                "id": id,
                "error": str(e)
            })
            raise

    async def create(self, table: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Create a new record.

        Args:
            table: Database table name
            data: Record data to create

        Returns:
            Created record as dictionary
        """
        url = self._build_url(table)

        try:
            response = await self.client.post(url, json=data)
            response.raise_for_status()
            logger.info({
                "event": "postgrest_create",
                "table": table,
                "id": response.json().get("id")
            })
            return response.json()
        except httpx.HTTPStatusError as e:
            logger.error({
                "event": "postgrest_create_error",
                "table": table,
                "status_code": e.response.status_code,
                "error": str(e)
            })
            raise
        except Exception as e:
            logger.error({
                "event": "postgrest_create_exception",
                "table": table,
                "error": str(e)
            })
            raise

    async def update(self, table: str, id: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Update an existing record.

        Args:
            table: Database table name
            id: Record ID
            data: Updated record data

        Returns:
            Updated record as dictionary
        """
        url = self._build_url(table, id)

        try:
            response = await self.client.patch(url, json=data)
            response.raise_for_status()
            logger.info({
                "event": "postgrest_update",
                "table": table,
                "id": id
            })
            return response.json()
        except httpx.HTTPStatusError as e:
            logger.error({
                "event": "postgrest_update_error",
                "table": table,
                "id": id,
                "status_code": e.response.status_code,
                "error": str(e)
            })
            raise
        except Exception as e:
            logger.error({
                "event": "postgrest_update_exception",
                "table": table,
                "id": id,
                "error": str(e)
            })
            raise

    async def delete(self, table: str, id: str) -> bool:
        """
        Delete a record.

        Args:
            table: Database table name
            id: Record ID

        Returns:
            True if deleted successfully
        """
        url = self._build_url(table, id)

        try:
            response = await self.client.delete(url)
            response.raise_for_status()
            logger.info({
                "event": "postgrest_delete",
                "table": table,
                "id": id
            })
            return True
        except httpx.HTTPStatusError as e:
            logger.error({
                "event": "postgrest_delete_error",
                "table": table,
                "id": id,
                "status_code": e.response.status_code,
                "error": str(e)
            })
            raise
        except Exception as e:
            logger.error({
                "event": "postgrest_delete_exception",
                "table": table,
                "id": id,
                "error": str(e)
            })
            raise

    async def rpc(
        self,
        function_name: str,
        params: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Call a PostgreSQL function via PostgREST RPC.

        Args:
            function_name: Name of the PostgreSQL function
            params: Parameters for the function

        Returns:
            Function result
        """
        url = f"/rpc/{function_name}"

        try:
            response = await self.client.post(url, json=params or {})
            response.raise_for_status()
            return response.json()
        except httpx.HTTPStatusError as e:
            logger.error({
                "event": "postgrest_rpc_error",
                "function": function_name,
                "status_code": e.response.status_code,
                "error": str(e)
            })
            raise
        except Exception as e:
            logger.error({
                "event": "postgrest_rpc_exception",
                "function": function_name,
                "error": str(e)
            })
            raise

    async def close(self):
        """Close the HTTP client."""
        await self.client.aclose()


# Global client instance (initialized in main.py)
postgrest_client: Optional[PostgRESTClient] = None


def get_postgrest_client() -> PostgRESTClient:
    """
    Dependency for FastAPI routes that provides PostgREST client.
    """
    if postgrest_client is None:
        raise RuntimeError("PostgREST client not initialized. Call init_postgrest_client() first.")
    return postgrest_client


def init_postgrest_client() -> PostgRESTClient:
    """
    Initialize global PostgREST client instance.
    Should be called during application startup.
    """
    global postgrest_client
    postgrest_client = PostgRESTClient()
    return postgrest_client