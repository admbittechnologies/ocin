-- OCIN Database Schema for PostgREST
-- This schema replaces SQLAlchemy models with PostgreSQL-native tables

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email TEXT NOT NULL UNIQUE,
    hashed_password TEXT NOT NULL,
    api_key TEXT UNIQUE,
    plan TEXT NOT NULL DEFAULT 'free',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Agents table
CREATE TABLE IF NOT EXISTS agents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    description TEXT,
    avatar_color TEXT DEFAULT '#6366f1',
    role TEXT NOT NULL DEFAULT 'worker',
    model_provider TEXT NOT NULL,
    model_id TEXT NOT NULL,
    temperature FLOAT DEFAULT 0.7,
    system_prompt TEXT,
    tool_ids UUID[],
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Tools table
CREATE TABLE IF NOT EXISTS tools (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    source TEXT NOT NULL,
    source_key TEXT,
    config JSONB DEFAULT '{}',
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Schedules table
CREATE TABLE IF NOT EXISTS schedules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    agent_id UUID REFERENCES agents(id) ON DELETE CASCADE,
    label TEXT NOT NULL,
    cron_expression TEXT NOT NULL,
    trigger_type TEXT NOT NULL DEFAULT 'cron',
    payload JSONB DEFAULT '{}',
    is_active BOOLEAN DEFAULT true,
    last_run_at TIMESTAMPTZ,
    next_run_at TIMESTAMPTZ
);

-- Runs table
CREATE TABLE IF NOT EXISTS runs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    agent_id UUID REFERENCES agents(id),
    schedule_id UUID REFERENCES schedules(id),
    status TEXT NOT NULL DEFAULT 'pending',
    input TEXT,
    output TEXT,
    tool_calls JSONB DEFAULT '[]',
    tokens_used INTEGER,
    cost_usd FLOAT,
    started_at TIMESTAMPTZ,
    finished_at TIMESTAMPTZ,
    error TEXT
);

-- Threads table
CREATE TABLE IF NOT EXISTS threads (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    agent_id UUID NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
    title TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Messages table
CREATE TABLE IF NOT EXISTS messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    thread_id UUID NOT NULL REFERENCES threads(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    agent_id UUID NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Agent memory table
CREATE TABLE IF NOT EXISTS agent_memory (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_id UUID NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
    key TEXT NOT NULL,
    value TEXT NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(agent_id, key)
);

-- Approvals table
CREATE TABLE IF NOT EXISTS approvals (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    run_id UUID NOT NULL REFERENCES runs(id) ON DELETE CASCADE,
    status TEXT NOT NULL DEFAULT 'pending',
    requested_by TEXT NOT NULL,
    requested_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    responded_by TEXT,
    response TEXT,
    responded_at TIMESTAMPTZ
);

-- Memory vectors table (for future vector search)
CREATE TABLE IF NOT EXISTS agent_memory_vectors (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_id UUID NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
    content TEXT NOT NULL,
    embedding vector(1536),
    source TEXT,
    source_id UUID,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_api_key ON users(api_key);
CREATE INDEX IF NOT EXISTS idx_agents_user_id ON agents(user_id);
CREATE INDEX IF NOT EXISTS idx_tools_user_id ON tools(user_id);
CREATE INDEX IF NOT EXISTS idx_schedules_user_id ON schedules(user_id);
CREATE INDEX IF NOT EXISTS idx_schedules_agent_id ON schedules(agent_id);
CREATE INDEX IF NOT EXISTS idx_runs_user_id ON runs(user_id);
CREATE INDEX IF NOT EXISTS idx_runs_agent_id ON runs(agent_id);
CREATE INDEX IF NOT EXISTS idx_runs_schedule_id ON runs(schedule_id);
CREATE INDEX IF NOT EXISTS idx_threads_user_id ON threads(user_id);
CREATE INDEX IF NOT EXISTS idx_threads_agent_id ON threads(agent_id);
CREATE INDEX IF NOT EXISTS idx_messages_thread_id ON messages(thread_id);
CREATE INDEX IF NOT EXISTS idx_agent_memory_agent_id ON agent_memory(agent_id);
CREATE INDEX IF NOT EXISTS idx_approvals_user_id ON approvals(user_id);
CREATE INDEX IF NOT EXISTS idx_approvals_run_id ON approvals(run_id);
CREATE INDEX IF NOT EXISTS idx_memory_vectors_agent_id ON agent_memory_vectors(agent_id);

-- Row Level Security (RLS) Policies
-- These ensure users can only access their own data
ALTER TABLE agents ENABLE ROW LEVEL SECURITY;
CREATE POLICY agents_user_isolation ON agents
    USING (user_id = current_user_id())
    WITH CHECK (true);

ALTER TABLE tools ENABLE ROW LEVEL SECURITY;
CREATE POLICY tools_user_isolation ON tools
    USING (user_id = current_user_id())
    WITH CHECK (true);

ALTER TABLE schedules ENABLE ROW LEVEL SECURITY;
CREATE POLICY schedules_user_isolation ON schedules
    USING (user_id = current_user_id())
    WITH CHECK (true);

ALTER TABLE runs ENABLE ROW LEVEL SECURITY;
CREATE POLICY runs_user_isolation ON runs
    USING (user_id = current_user_id())
    WITH CHECK (true);

ALTER TABLE threads ENABLE ROW LEVEL SECURITY;
CREATE POLICY threads_user_isolation ON threads
    USING (user_id = current_user_id())
    WITH CHECK (true);

ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY messages_user_isolation ON messages
    USING (user_id = current_user_id())
    WITH CHECK (true);

ALTER TABLE agent_memory ENABLE ROW LEVEL SECURITY;
CREATE POLICY agent_memory_user_isolation ON agent_memory
    USING (EXISTS (SELECT 1 FROM agents WHERE id = agent_memory.agent_id AND user_id = current_user_id()))
    WITH CHECK (true);

ALTER TABLE approvals ENABLE ROW LEVEL SECURITY;
CREATE POLICY approvals_user_isolation ON approvals
    USING (user_id = current_user_id())
    WITH CHECK (true);

-- Function to get current user ID from JWT token
CREATE OR REPLACE FUNCTION current_user_id()
RETURNS UUID
LANGUAGE sql
SECURITY DEFINER
AS $$
BEGIN
    DECLARE user_id UUID;
    SELECT id INTO user_id FROM users WHERE api_key = current_setting('request.jwt.claims')::text;
    RETURN user_id;
EXCEPTION WHEN NO_DATA_FOUND THEN
    RETURN NULL;
END;
$$ STABLE;

-- Function to extract user ID from JWT token
CREATE OR REPLACE FUNCTION extract_user_id_from_token()
RETURNS UUID
LANGUAGE sql
SECURITY DEFINER
AS $$
    SELECT current_user_id();
$$ STABLE;