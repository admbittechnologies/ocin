# OCIN Backend

Lean SaaS platform for personal AI agents. Stateless, config-driven agent execution powered by PydanticAI.

## Architecture

**PostgREST Server + FastAPI Hybrid Approach**

The backend uses a hybrid architecture:
- **PostgREST Server**: Automatic REST API for PostgreSQL, handling all CRUD operations
- **FastAPI**: Business logic layer for agent execution, scheduling, and complex workflows
- **Database**: PostgreSQL 16 with pgvector for vector search (v2)

```
Client → FastAPI (Business Logic) → PostgREST → PostgreSQL
```

### Key Components

#### PostgREST Server (`config.pgrst`, `schema.sql`)
- Handles all database CRUD operations automatically
- Provides JWT authentication and row-level security
- Generates REST API from database schema
- No manual SQL or ORM code needed

#### FastAPI Application (`app/`)
- **Agent Runner**: Core business logic using PydanticAI
- **Scheduling**: Schedule management and cron parsing
- **Integrations**: External API wrappers (Composio, Apify, Maton)
- **WebSocket**: Real-time streaming for agent execution
- **Authentication**: User registration and login (JWT managed by PostgREST)

#### Services (`app/services/`)
- Updated to work with PostgREST client for data operations
- Maintain business logic in FastAPI layer

## Quick Start

```bash
# Copy environment variables
cp .env.example .env

# Start services
docker-compose up -d

# Apply database schema to PostgREST
# (First time only - schema.sql is auto-mounted)
docker-compose exec postgrest psql -U ocin -d ocin -f /docker-entrypoint-initdb.d/init.sql

# Start FastAPI application
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

## Tech Stack

| Layer | Technology | Notes |
|---|---|---|
| **Database Layer** | PostgREST Server | Auto-generates REST API from PostgreSQL schema |
| **API Server** | FastAPI | Business logic layer for complex workflows |
| **Database** | PostgreSQL 16 + pgvector | Persistent storage with vector search capability |
| **Cache/Queue** | Redis 7 | Run state, streaming tokens, session TTL |
| **Scheduler** | APScheduler | One central instance inside FastAPI process |
| **Auth** | JWT (python-jose) + bcrypt | Email + password login |
| **Agent Framework** | PydanticAI | Multi-agent, type-safe, model-agnostic |

## Project Structure

```
backend/
├── config.pgrst           # PostgREST server configuration
├── schema.sql             # PostgreSQL database schema for PostgREST
├── docker-compose.yml       # All services (PostgREST, PostgreSQL, Redis, FastAPI)
├── app/
│   ├── main.py          # FastAPI app, lifespan, routers, central scheduler
│   ├── config.py        # Settings via pydantic-settings
│   ├── postgrest_client.py  # PostgREST client wrapper
│   ├── models/          # Legacy SQLAlchemy models (being deprecated)
│   ├── schemas/         # Pydantic v2 schemas
│   ├── routers/         # API route handlers
│   ├── services/        # Business logic (updated for PostgREST)
│   │   ├── agent_runner.py     # PydanticAI agent execution
│   │   ├── schedule_service.py  # Schedule management (updated)
│   │   ├── tool_loader.py      # Tool loading from PostgREST
│   │   ├── run_service.py       # Run CRUD operations (updated)
│   │   └── thread_service.py    # Thread/memory operations (updated)
│   ├── integrations/    # External API wrappers
│   │   ├── composio.py      # Composio API wrapper
│   │   ├── apify.py         # Apify Actor runner
│   │   └── maton_gateway.py  # Maton.ai gateway HTTP client
│   └── core/            # Security, dependencies, exceptions
└── .env.example          # Environment variables template
```

## API Endpoints

**PostgREST Auto-generated Endpoints** (via schema.sql):
- `GET /users` - List users (with RLS filtering)
- `POST /users` - Create user
- `GET /agents` - List agents
- `POST /agents` - Create agent
- `GET /tools` - List tools
- `POST /tools` - Create tool
- `GET /runs` - List runs
- `POST /runs` - Create run
- `GET /schedules` - List schedules
- `POST /schedules` - Create schedule
- `GET /threads` - List threads
- `POST /threads` - Create thread
- `GET /messages` - List messages
- `POST /messages` - Create message
- `GET /agent_memory` - List agent memory
- `POST /agent_memory` - Create memory entry
- `GET /approvals` - List approvals
- `POST /approvals` - Create approval

**FastAPI Custom Endpoints** (complex business logic):
- `POST /api/v1/auth/register` - User registration
- `POST /api/v1/auth/login` - User login
- `POST /api/v1/runs/trigger` - Trigger agent run
- `WS /api/v1/runs/{id}/stream` - Stream run output
- `POST /api/v1/schedules/` - Create schedule (business logic)
- Webhooks for external triggers
- Admin endpoints for plan management

## PostgREST Query Parameters

PostgREST uses HTTP query parameters instead of SQL:
- **Filtering**: `?user_id=eq.{uuid}`
- **Ordering**: `?order=created_at.desc`
- **Limit**: `?limit=10`
- **Offset**: `?offset=20`
- **Selection**: `?select=id,name,email`

## Row Level Security

PostgREST handles user isolation automatically via RLS policies:
- Users can only access their own data
- No need for manual `user_id` filtering in application code
- PostgREST extracts user ID from JWT token automatically

## Running Locally

```bash
# Install dependencies
pip install -r requirements.txt

# Start PostgreSQL and Redis (or use Docker)
docker-compose up -d db redis

# Start PostgREST server
docker-compose up -d postgrest

# Start FastAPI application
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

## Development

### Testing PostgREST

```bash
# Test PostgREST server health
curl http://localhost:3000/

# Test with PostgREST client authentication
curl -H "apikey: your-api-key" http://localhost:3000/users
```

### Migration Guide

See `docs/postgrest-migration-guide.md` for detailed migration steps from SQLAlchemy to PostgREST.

## Benefits of PostgREST Approach

1. **Simplified data layer**: No more SQLAlchemy models or ORM code
2. **Better performance**: PostgREST is optimized for PostgreSQL
3. **Built-in security**: Row-level security handled automatically
4. **Automatic API**: REST API generated from database schema
5. **Separation of concerns**: Clear separation between business logic and data layer
6. **Type safety**: Strong typing from PostgREST generated API