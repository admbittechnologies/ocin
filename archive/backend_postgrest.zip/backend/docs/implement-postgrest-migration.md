# Postgrest Migration Implementation

## Overview
Migrate from SQLAlchemy ORM to Postgrest for approval system integration.

## Phase 1: Setup (Day 1-3)

### Install Dependencies
```bash
npm install prisma @prisma/client
npm install @prisma/client
npm install @prisma/adapter-pg
```

### Initialize Prisma
```bash
npx prisma init
```

### Generate Schema
```bash
npx prisma db pull
npx prisma db push
```

## Phase 2: Schema Conversion (Day 4-7)

### Update Database Models
Modify SQLAlchemy models to add Postgrest compatibility:

```python
# Add to models/run.py
from pydantic import BaseModel
from prisma import enums as PrismaEnum

class RunStatus(str, PrismaEnum):
    PENDING = "pending"
    RUNNING = "running"
    AWAITING_APPROVAL = "awaiting_approval"
    SUCCESS = "success"
    FAILED = "failed"

# Update to models/approval.py
from pydantic import BaseModel
from prisma import enums as PrismaEnum

class ApprovalStatus(str, PrismaEnum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    EXPIRED = "expired"
```

## Phase 3: Backend Services Update (Day 8-14)

### Update Approval Service
```python
# Replace SQLAlchemy queries with dual-ORM support
from sqlalchemy import select, or_
from app.models.approval import Approval as SQLAApproval
from app.models.approval import Approval as PrismaApproval

async def create_approval(...):
    # Check if Postgrest mode is enabled
    if settings.POSTGRES_MODE != "sqlalchemy":
        # Use Prisma
        approval = PrismaApproval.create(...)
    else:
        # Use SQLAlchemy
        approval = SQLAApproval(...)
```

### Update Agent Runner
```python
# Add Prisma queries alongside SQLAlchemy
async def get_agent_with_tools(...):
    if settings.POSTGRES_MODE != "sqlalchemy":
        # Use Prisma
        return await prisma.agent.find_unique(...)
    else:
        # Use SQLAlchemy
        return await get_agent(...)
```

## Phase 4: Frontend Updates (Day 15-18)

### Update API Client
```typescript
// Update API client to handle new approval status types
type ApprovalStatus = "pending" | "awaiting_approval" | "approved" | "rejected"
```

### Add Approval Polling
```typescript
// Add automatic polling for approval status changes
const pollApprovals = () => {
  const response = await fetch('/api/v1/approvals?status=pending')
  if (response.approvals || []).length > 0) {
    await handleNewApprovals(response.approvals)
  }
}, 3000) // Poll every 3 seconds
```

## Phase 5: Testing (Day 22-25)

### Test Dual-ORM Compatibility
- Test approval creation with both SQLAlchemy and Prisma
- Verify data integrity
- Test rollback procedures
- Performance benchmarking

## Phase 6: Deployment (Day 29-35)

### Feature Flags
```python
# Add to config.py
POSTGRES_MODE = Literal["sqlalchemy", "prisma", "dual"]
```

### Gradual Rollout
- Deploy with 10% traffic to Prisma
- Monitor error rates
- Full rollback after 1 week

## Success Criteria
- Approvals visible in frontend
- No data loss
- Zero functionality regression
- Clean rollback capability

## Rollback Strategy

### Immediate (24h)
- Revert to last successful migration
- Switch POSTGRES_MODE to "sqlalchemy"

### Phase Rollback (1 week)
- If rollback needed, revert to Prisma
- Maintain both systems during rollback

## Timeline

- **Phase 1**: 3 days (Setup)
- **Phase 2**: 7 days (Schema + Services)
- **Phase 3**: 14 days (Frontend)
- **Phase 4**: 14 days (Frontend + Testing)
- **Phase 5**: 13 days (Testing)
- **Phase 6**: 14 days (Deployment)

Total: 65 days (9.5 weeks)