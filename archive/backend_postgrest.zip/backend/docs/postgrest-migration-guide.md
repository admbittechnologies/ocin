# PostgREST Server Migration Guide

## Architecture Overview

With PostgREST Server approach, the architecture changes from:
```
FastAPI + SQLAlchemy → PostgreSQL
```
To:
```
FastAPI (Business Logic) + PostgREST (Data Layer) → PostgreSQL
```

## What Changes

### PostgREST Handles Automatically
- CRUD operations (Create, Read, Update, Delete)
- Row Level Security (RLS) for user isolation
- JWT authentication and authorization
- Automatic API generation from database schema
- Filtering, sorting, pagination via HTTP parameters

### What Remains in FastAPI
The following business logic components remain but need to be updated to work with PostgREST:

#### 1. Agent Runner (`app/services/agent_runner.py`)
**Status**: Remains with updates
- **What it does**: Core business logic using PydanticAI for agent execution
- **Changes needed**:
  - Replace SQLAlchemy queries with PostgREST client calls
  - Update `get_agent_with_tools()` to use PostgREST
  - Update tool loading from database
  - Update run status tracking via PostgREST

#### 2. Schedule Service (`app/services/schedule_service.py`)
**Status**: Remains with updates
- **What it does**: Schedule management, cron parsing, APScheduler integration
- **Changes needed**:
  - Replace SQLAlchemy queries with PostgREST client calls
  - Update `create_schedule()` to use PostgREST
  - Update `get_schedules()` to use PostgREST
  - Update `update_schedule()` to use PostgREST
  - Update `delete_schedule()` to use PostgREST

#### 3. Tool Loader (`app/services/tool_loader.py`)
**Status**: Remains with updates
- **What it does**: Loads tool configurations from database for agent execution
- **Changes needed**:
  - Replace SQLAlchemy queries with PostgREST client calls
  - Update `get_tools_by_user()` to use PostgREST
  - Update `get_tools_for_agent()` to use PostgREST

#### 4. Run Service (`app/services/run_service.py`)
**Status**: Remains with updates
- **What it does**: Run CRUD operations, history management
- **Changes needed**:
  - Replace SQLAlchemy queries with PostgREST client calls
  - Update `create_run()` to use PostgREST
  - Update `get_run()` to use PostgREST
  - Update `update_run()` to use PostgREST
  - Update `get_runs()` to use PostgREST

#### 5. Thread/Memory Services
**Status**: Remains with updates
- **What they do**: Conversation context storage and retrieval
- **Changes needed**:
  - Replace SQLAlchemy queries with PostgREST client calls
  - Update `save_messages()` to use PostgREST
  - Update `get_thread()` to use PostgREST
  - Update `save_memory()` to use PostgREST
  - Update `get_memory()` to use PostgREST

#### 6. Approval Service (`app/services/approval_service.py`)
**Status**: Remains with updates
- **What it does**: Approval workflow management
- **Changes needed**:
  - Replace SQLAlchemy queries with PostgREST client calls
  - Update `create_approval()` to use PostgREST
  - Update `get_approval()` to use PostgREST
  - Update `update_approval()` to use PostgREST

#### 7. External Integrations
**Status**: No changes needed
- **Composio** (`app/integrations/composio.py`): External API calls, no database changes
- **Apify** (`app/integrations/apify.py`): External API calls, no database changes
- **Maton** (`app/integrations/maton_gateway.py`): External API calls, no database changes

#### 8. Authentication (`app/core/security.py`)
**Status**: No changes needed
- **What it does**: JWT token validation, password hashing
- **Why**: JWT authentication is handled by PostgREST, user management stays in FastAPI

#### 9. WebSockets (`app/routers/runs.py`)
**Status**: Minor updates
- **What it does**: Real-time streaming of agent execution
- **Changes needed**: May need to integrate PostgREST real-time notifications

#### 10. Routers
**Status**: Updates to use new service layer
- **What they do**: HTTP route handlers that call services
- **Changes needed**: All routers need to work with updated services that use PostgREST

## Implementation Priority

### Phase 1: Core Infrastructure (High Priority)
1. ✅ Set up PostgREST server configuration (`config.pgrst`)
2. ✅ Create database schema for PostgREST (`schema.sql`)
3. ✅ Update docker-compose with PostgREST service
4. ✅ Update environment configuration

### Phase 2: Service Layer Updates (High Priority)
5. ⏳ Replace SQLAlchemy in agent_runner.py
6. ⏳ Replace SQLAlchemy in schedule_service.py
7. ⏳ Replace SQLAlchemy in tool_loader.py
8. ⏳ Replace SQLAlchemy in run_service.py
9. ⏳ Replace SQLAlchemy in thread/memory services
10. ⏳ Replace SQLAlchemy in approval_service.py

### Phase 3: Router Updates (Medium Priority)
11. ⏳ Update all routers to work with new service layer
12. ⏳ Update WebSocket streaming if needed

### Phase 4: Cleanup (Low Priority)
13. ⏳ Remove or deprecate SQLAlchemy models
14. ⏳ Remove database.py and related ORM code
15. ⏳ Update documentation

## Key Technical Notes

### PostgREST Query Parameters
PostgREST uses HTTP query parameters instead of SQL:
- **Filtering**: `?user_id=eq.{uuid}`
- **Ordering**: `?order=created_at.desc`
- **Limit**: `?limit=10`
- **Offset**: `?offset=20`
- **Selection**: `?select=id,name,email`

### Row Level Security
PostgREST handles user isolation automatically via RLS policies:
- Users can only access their own data
- No need for manual `user_id` filtering in application code
- PostgREST extracts user ID from JWT token automatically

### Benefits of This Approach
1. **Simplified data layer**: No more SQLAlchemy models or ORM code
2. **Better performance**: PostgREST is optimized for PostgreSQL
3. **Built-in security**: Row-level security handled automatically
4. **Automatic API**: REST API generated from schema
5. **Separation of concerns**: Clear separation between business logic and data layer

## Testing Strategy
1. Test PostgREST server independently
2. Test updated services with PostgREST calls
3. Test end-to-end workflows (auth → agent run → result)
4. Verify user isolation (users can't access other users' data)
5. Test WebSocket streaming if changed

## Rollback Plan
If PostgREST migration fails:
1. Stop PostgREST container
2. Start FastAPI container (still using PostgreSQL)
3. Update docker-compose to revert to previous configuration
4. Verify SQLAlchemy connections work correctly
5. Gradual rollback to confirm stability